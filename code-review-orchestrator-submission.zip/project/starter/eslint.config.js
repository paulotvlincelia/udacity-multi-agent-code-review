/**
 * Minimal flat config, present so the ESLint MCP server has rules to apply.
 *
 * The server's lint-files tool needs a resolvable config or it returns nothing
 * useful, which would leave the configured MCP server permanently unexercised.
 * Scope is deliberately narrow: this lints the reviewed repository's files as
 * mechanical evidence for the code-quality agent, it is not a style gate on this
 * project (that is `tsc --noEmit` via `npm run lint`).
 */
export default [
  {
    files: ['**/*.js', '**/*.jsx', '**/*.mjs', '**/*.cjs'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: {
        // Browser globals, since the reviewed fixtures are front-end files.
        document: 'readonly',
        window: 'readonly',
        fetch: 'readonly',
        console: 'readonly'
      }
    },
    rules: {
      // Findings a linter settles reliably, freeing the agents to reason about
      // what a linter cannot see.
      'no-unused-vars': 'warn',
      'no-undef': 'error',
      'no-eval': 'error',
      'no-implied-eval': 'error',
      'no-var': 'warn',
      'prefer-const': 'warn',
      eqeqeq: ['warn', 'always'],
      'no-shadow': 'warn'
    }
  },
  {
    // This project's own sources are type-checked, not linted here.
    ignores: ['dist/**', 'node_modules/**', 'src/**', 'tests/**', 'reports/**']
  }
];
