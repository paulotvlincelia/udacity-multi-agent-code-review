import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/index.js';

/**
 * Refactoring Suggester subagent.
 *
 * Improves working code: modernization, extraction, naming, design patterns.
 * Correctness problems belong to code-quality-analyzer, and the description
 * states the boundary so the orchestrator does not send the same concern twice.
 *
 * No Glob: this agent operates on the file it was handed and has no reason to
 * discover others.
 */
export const refactoringSuggester: AgentDefinition = {
  description:
    'Use this agent to improve code that already works: extracting functions, ' +
    'renaming for clarity, modernizing dated constructs, simplifying nested ' +
    'logic and applying design patterns. Every suggestion carries before and ' +
    'after code. Use it for questions of form and structure - defects and ' +
    'vulnerabilities belong to the code quality agent instead.',
  prompt: REFACTORING_SUGGESTER_PROMPT,
  tools: ['Read', 'Grep', 'Skill'],
  model: 'inherit'
};
