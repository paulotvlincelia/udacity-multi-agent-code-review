import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/index.js';

/**
 * Code Quality Analyzer subagent.
 *
 * Finds defects: security vulnerabilities, performance problems, maintainability
 * decay and bug risk. The sibling refactoring-suggester handles working code that
 * could read better - the description below is written to make the orchestrator
 * pick correctly between them.
 *
 * Tools are least privilege: read and search only. Analysis never needs to write
 * a file or run a command, and withholding those tools removes the possibility.
 * Skill is what reaches the .claude/skills/ library - it only resolves when the
 * query also sets settingSources: ['project'].
 */
export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Use this agent to find defects in a source file: security vulnerabilities ' +
    '(injection, hardcoded secrets, broken authorization), performance problems, ' +
    'maintainability decay and bug risk. Returns severity-graded issues with line ' +
    'numbers. Use it when you need to know what is wrong with code, as opposed to ' +
    'what could be written more elegantly.',
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill'],
  model: 'inherit'
};
