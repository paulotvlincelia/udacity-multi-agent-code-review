import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/index.js';

/**
 * Test Coverage Analyzer subagent.
 *
 * Estimates coverage structurally rather than by execution: it locates test files
 * by convention, enumerates the symbols and branches in the source, and checks
 * which ones carry a real assertion.
 *
 * Glob matters more here than for the other two agents - discovering the test
 * files is the first step of the method, not an optimisation.
 */
export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Use this agent to assess how well a source file is covered by tests. It ' +
    'locates the test files, enumerates functions and branches that have no ' +
    'assertion behind them, estimates a coverage percentage, and suggests ' +
    'specific test cases naming the call, the input and the assertion. Use it ' +
    'when you need to know what is untested, not whether the code is correct.',
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill'],
  model: 'inherit'
};
