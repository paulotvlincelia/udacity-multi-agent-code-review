import type { McpServerConfig } from '@anthropic-ai/claude-agent-sdk';

/**
 * Model Context Protocol (MCP) server configurations
 *
 * Two servers give the orchestrator its external reach:
 * 1. GitHub - pull request metadata, changed files, file contents
 * 2. ESLint - linting and style analysis over those files
 *
 * Documentation:
 * - MCP Protocol: https://modelcontextprotocol.io
 * - GitHub MCP: https://github.com/github/github-mcp-server
 * - ESLint MCP: https://eslint.org/docs/latest/use/mcp
 */
export const mcpServersConfig: Record<string, McpServerConfig> = {
  /**
   * GitHub MCP Server.
   *
   * The server reads its credential from GITHUB_PERSONAL_ACCESS_TOKEN, while this
   * project's .env uses GITHUB_TOKEN, so the name is remapped here.
   *
   * The token is optional - it raises the GitHub rate limit from 60 to 5000
   * requests per hour and unlocks private repositories. It falls back to an empty
   * string rather than undefined because the stdio transport rejects undefined
   * env values outright, which would fail the connection instead of degrading to
   * anonymous access.
   */
  github: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: { GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '' }
  },

  /**
   * ESLint MCP Server.
   *
   * Runs locally against the checked-out files, so it needs no credential.
   */
  eslint: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@eslint/mcp@latest'],
    env: {}
  }
};
