/**
 * Centralized prompt management
 *
 * Relative specifiers carry the .js extension: this package is "type": "module"
 * with "module": "ESNext", and tsc does not rewrite import paths.
 */

export { buildOrchestratorPrompt } from './orchestrator.prompt.js';
export { CODE_QUALITY_ANALYZER_PROMPT } from './code-quality-analyzer.prompt.js';
export { TEST_COVERAGE_ANALYZER_PROMPT } from './test-coverage-analyzer.prompt.js';
export { REFACTORING_SUGGESTER_PROMPT } from './refactoring-suggester.prompt.js';
