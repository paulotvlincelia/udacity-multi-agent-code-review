/**
 * Prompt for the main orchestrator.
 *
 * Two things this prompt has to force, or the run looks successful and is not:
 *
 * 1. Fetch first, then delegate. The model is capable of reading the diff and
 *    writing the whole report itself. That produces a populated report while
 *    failing the criteria that grade subagent spawning and Skills integration.
 *    So the delegation is written as an imperative naming each agent, not as a
 *    description of what should happen.
 * 2. Every file gets all three agents. Partial fan-out yields a report whose
 *    fileReviews entries are missing required sections, which fails Zod.
 */
export function buildOrchestratorPrompt(
  owner: string,
  repo: string,
  prNumber: number,
  maxFiles: number
): string {
  return `Review pull request #${prNumber} in the GitHub repository ${owner}/${repo}.

Work in three stages, in this order. Do not skip ahead.

## Stage 1 - Fetch the pull request

Use the GitHub MCP tools to gather the data:

1. Fetch the pull request metadata for ${owner}/${repo} #${prNumber}.
2. Fetch the list of files the pull request changes.
3. Select the files worth reviewing: source files only. Skip lock files,
   generated output, images, and anything over 1500 lines. Review at most
   ${maxFiles} files - if there are more, take the ones with the largest number
   of changed lines.
4. For each selected file, fetch its **full contents at the pull request's head
   commit**. The patch alone is not enough: a security judgement needs the
   surrounding code, not just the changed lines.
5. For any JavaScript or TypeScript file among them, also run the ESLint MCP tools
   over the file and keep the findings. Lint output is mechanical evidence that
   complements the model's reading: it catches the unused binding and the
   shadowed variable reliably, which frees the subagents to reason about the
   things a linter cannot see. If the ESLint server is unavailable, note that and
   carry on - it is supporting evidence, not a blocker.

## Stage 2 - Delegate to the three subagents

For each selected file, use the Task tool three times. Issue all three calls for
a file together so they run in parallel, then move to the next file.

For a file at path P, make exactly these three calls:

1. Use the Task tool with subagent_type "code-quality-analyzer" and a prompt that
   gives it the path P and the full file contents, and asks it to analyse the
   file for security, performance, maintainability and bug-risk issues.
2. Use the Task tool with subagent_type "test-coverage-analyzer" and a prompt that
   gives it the path P and the full file contents, and asks it to assess test
   coverage and identify untested paths.
3. Use the Task tool with subagent_type "refactoring-suggester" and a prompt that
   gives it the path P and the full file contents, and asks it to identify
   refactoring opportunities with before and after code.

Do not analyse the code yourself. Your findings come from the subagents. If you
write an issue that no subagent reported, the review is invalid - the one exception
is a lint finding from Stage 1, which you may pass to the code-quality subagent as
additional context for it to judge.

If a subagent fails or returns something unusable for a file, keep going. Record
that section as a failure - described in Stage 3 - rather than dropping the file
or aborting the review.

## Stage 3 - Aggregate into the final report

Combine every subagent result into a single report with this structure:

- \`pullRequest\`: { owner: "${owner}", repo: "${repo}", number: ${prNumber} }
- \`fileReviews\`: one entry per file you reviewed, each with
  - \`file\`: the path
  - \`codeQuality\`: the code-quality-analyzer result for that file, verbatim
  - \`testCoverage\`: the test-coverage-analyzer result for that file, verbatim
  - \`refactorings\`: the refactoring-suggester result for that file, verbatim
- \`summary\`:
  - \`totalFiles\`: how many files are in fileReviews
  - \`overallScore\`: the mean of every codeQuality.overallScore, rounded
  - \`criticalIssues\`: count of issues across all files with severity "critical"
  - \`highPriorityTests\`: count of untestedPaths across all files whose priority
    is "critical" or "high"
  - \`refactoringOpportunities\`: total count of suggestions across all files
- \`recommendations\`: the 3 to 5 actions that matter most across the whole pull
  request, each with a priority of "critical", "high", "medium" or "low", a
  category, a description, and the list of files it applies to. Order them by
  priority. These are cross-cutting takeaways, not a copy of individual issues.
- \`metadata\`:
  - \`analyzedAt\`: the current time as an ISO 8601 string
  - \`duration\`: 0 (the caller overwrites this with the measured wall time)
  - \`agentVersions\`: { "code-quality-analyzer": "1.0.0",
    "test-coverage-analyzer": "1.0.0", "refactoring-suggester": "1.0.0" }

### When a subagent failed for a file

Never omit a section - all three are required, and an omission makes the whole
report invalid. Fill the failed one with a valid object that says so:

- codeQuality: { file: P, issues: [], overallScore: 0,
  summary: "Analysis failed: <reason>" }
- testCoverage: { file: P, hasTests: false, testFiles: [], untestedPaths: [],
  coverageEstimate: 0, summary: "Analysis failed: <reason>" }
- refactorings: { file: P, suggestions: [],
  summary: "Analysis failed: <reason>" }

Exclude a failed section's score from the overallScore mean rather than counting
it as a zero, so one failure does not distort the whole pull request's rating.`;
}
