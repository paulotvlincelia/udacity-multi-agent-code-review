/**
 * Utility exports
 *
 * Logger and ReportGenerator ship with the starter; the error handler and rate
 * limiter are implemented here. Relative specifiers carry .js - this package is
 * "type": "module" and tsc does not rewrite import paths.
 */

export { logger } from './logger.js';
export { ReportGenerator } from './report-generator.js';

export { RateLimiter, globalRateLimiter, withRateLimit, DEFAULT_RATE_LIMITS } from './rate-limiter.js';
export type { RateLimiterConfig } from './rate-limiter.js';

export {
  ReviewError,
  ErrorCodes,
  withRetry,
  withTimeout,
  isReviewError,
  formatError
} from './error-handler.js';
export type { ErrorCode } from './error-handler.js';
