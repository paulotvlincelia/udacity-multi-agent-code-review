import * as dotenv from 'dotenv';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { CodeReviewOrchestrator } from './orchestrator.js';
import type { ReviewReport } from './types/index.js';
import { ReportGenerator, logger, formatError, isReviewError } from './utils/index.js';
import { logReviewStart, logReviewComplete, logReviewError } from './utils/logger.js';

dotenv.config();

const REPORTS_DIR = 'reports';

const USAGE = `
Multi-Agent Code Review

  Usage: npm run dev -- <owner> <repo> <pr-number>

  owner      GitHub user or organisation
  repo       Repository name
  pr-number  Pull request number (positive integer)

  Example: npm run dev -- octocat Hello-World 1
`;

/** Print a failure the way a user can act on, then stop. */
function fail(message: string, detail?: string): never {
  console.error(`\n✖ ${message}`);
  if (detail) console.error(detail);
  process.exit(1);
}

interface Args {
  owner: string;
  repo: string;
  prNumber: number;
}

/** Parse and validate the three positional arguments. */
export function parseArgs(argv: string[]): Args {
  const [owner, repo, prStr] = argv;

  if (!owner || !repo || !prStr) {
    fail('Missing required arguments.', USAGE);
  }

  // Number() accepts '1.5', '0x10' and ' 1 '; the regex pins it to digits only,
  // so a PR number is what it looks like.
  if (!/^\d+$/.test(prStr)) {
    fail(
      `Invalid pull request number: "${prStr}".`,
      '  The PR number must be a positive integer, for example 42.'
    );
  }

  const prNumber = Number(prStr);
  if (prNumber < 1) {
    fail(
      `Invalid pull request number: "${prStr}".`,
      '  Pull request numbers start at 1.'
    );
  }

  return { owner, repo, prNumber };
}

/**
 * Confirm a usable credential is present and report which one.
 *
 * Three paths are supported: an Anthropic API key, AWS Bedrock credentials, or
 * an authenticated Claude CLI session that the SDK inherits.
 */
export function validateAuth(env: NodeJS.ProcessEnv = process.env): string {
  const hasAnthropicKey = Boolean(env.ANTHROPIC_API_KEY);
  const hasAwsKeys = Boolean(env.AWS_ACCESS_KEY_ID && env.AWS_SECRET_ACCESS_KEY);
  const hasBedrockFlag = env.CLAUDE_CODE_USE_BEDROCK === '1';

  if (hasAwsKeys || hasBedrockFlag) {
    if (!env.AWS_REGION) {
      fail(
        'AWS Bedrock selected but AWS_REGION is not set.',
        '  Set AWS_REGION, for example: AWS_REGION=us-east-1'
      );
    }
    console.log('🔐 Using AWS Bedrock authentication');
    return 'bedrock';
  }

  if (hasAnthropicKey) {
    console.log('🔐 Using Anthropic API authentication');
    return 'anthropic-api';
  }

  // No explicit credential in the environment. The SDK can still inherit an
  // authenticated Claude CLI session, which is how this project was developed -
  // but "no API key" and "no credential at all" are different situations and
  // only the second is a hard failure. So detect the session rather than
  // assuming either way.
  if (hasClaudeCliInstalled()) {
    console.log('🔐 Using inherited Claude CLI session');
    console.log(
      '   To use an API key instead, set ANTHROPIC_API_KEY, or set\n' +
        '   AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION for Bedrock.'
    );
    return 'cli-session';
  }

  fail(
    'No authentication method is configured.',
    '  Choose one of:\n' +
      '    ANTHROPIC_API_KEY=sk-ant-...                        (Anthropic API)\n' +
      '    AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION  (Bedrock)\n' +
      '    claude login                                        (CLI session)'
  );
}

/**
 * Whether a Claude CLI installation is present for the SDK to inherit auth from.
 *
 * Deliberately a weak signal: where the credential lives is platform-specific
 * and not a stable interface - macOS keeps it in the Keychain, not on disk - so
 * probing for a credential file gives false negatives. The presence of the CLI's
 * config directory says "this machine may have a session"; the SDK remains the
 * authority on whether it is valid, and fails fast and clearly if it is not.
 *
 * The purpose here is only to distinguish "no credential configured anywhere",
 * which is a usage error worth catching before any network call, from "no API
 * key but possibly a session", which is a supported setup.
 */
function hasClaudeCliInstalled(env: NodeJS.ProcessEnv = process.env): boolean {
  const home = env.HOME ?? env.USERPROFILE;
  if (!home) return false;
  return existsSync(join(home, '.claude'));
}

/** ANTHROPIC_MODEL is required whichever credential path is in use. */
export function validateModel(env: NodeJS.ProcessEnv = process.env): string {
  const model = env.ANTHROPIC_MODEL;

  if (!model) {
    fail(
      'ANTHROPIC_MODEL is not set.',
      '  Anthropic API: ANTHROPIC_MODEL=claude-sonnet-4-5-20250929\n' +
        '  AWS Bedrock:   ANTHROPIC_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0'
    );
  }

  return model;
}

/**
 * Write the review in all three formats.
 *
 * Two naming conventions, because the brief asks for both: the per-PR files
 * Phase 6 and the submission checklist enumerate, plus the generic
 * report.{ext} the Production Deliverables table names.
 */
export function writeReports(report: ReviewReport, owner: string, repo: string, prNumber: number): string[] {
  const generator = new ReportGenerator();
  mkdirSync(REPORTS_DIR, { recursive: true });

  // The brief names the nine deliverables after a fixture repository that is no
  // longer reachable, so the analysis runs against an accessible copy under a
  // different owner. REPORT_OWNER keeps the submitted filenames as the brief
  // specifies while the report's own pullRequest field records what was really
  // analysed. See DEVIATIONS.md.
  const fileOwner = process.env.REPORT_OWNER || owner;

  const formats: Array<[extension: string, contents: string]> = [
    ['json', JSON.stringify(report, null, 2)],
    ['md', generator.generateMarkdownReport(report)],
    ['html', generator.generateHTMLReport(report)]
  ];

  // The generic copy is written only when there is an analysis to write.
  //
  // Both names are produced by every run, so the last run wins on report.{ext}
  // - and a pull request with no analysable files produces a valid but empty
  // report, which would silently replace a dense one. The per-PR file is always
  // written because it is addressed by name and overwrites only itself; the
  // generic copy is shared, so an empty result must not claim it.
  const hasAnalysis = report.fileReviews.length > 0;

  const written: string[] = [];
  for (const [extension, contents] of formats) {
    const names = [`${fileOwner}_${repo}_${prNumber}.${extension}`];
    if (hasAnalysis) names.push(`report.${extension}`);

    for (const name of names) {
      const path = join(REPORTS_DIR, name);
      writeFileSync(path, contents, 'utf8');
      written.push(path);
    }
  }

  if (!hasAnalysis) {
    logger.warn('Empty review: generic report.{json,md,html} left untouched', {
      owner,
      repo,
      prNumber
    });
  }

  return written;
}

async function main(): Promise<void> {
  const { owner, repo, prNumber } = parseArgs(process.argv.slice(2));
  validateAuth();
  const model = validateModel();

  console.log(`\n🔍 Reviewing ${owner}/${repo}#${prNumber} with ${model}\n`);
  logReviewStart(owner, repo, prNumber);

  const startedAt = Date.now();

  try {
    const orchestrator = new CodeReviewOrchestrator();
    const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);
    const written = writeReports(report, owner, repo, prNumber);

    const duration = Date.now() - startedAt;
    logReviewComplete(owner, repo, prNumber, report.summary.overallScore, duration);

    console.log(`\n✔ Review complete in ${(duration / 1000).toFixed(1)}s`);
    console.log(`  Score ${report.summary.overallScore}/100 across ${report.summary.totalFiles} file(s)`);
    console.log(`  ${report.summary.criticalIssues} critical issue(s), ` +
      `${report.summary.highPriorityTests} high-priority test gap(s), ` +
      `${report.summary.refactoringOpportunities} refactoring opportunity(ies)`);
    console.log('\n  Reports written:');
    for (const path of written) console.log(`    ${path}`);
    console.log();
  } catch (error) {
    logReviewError(owner, repo, prNumber, error instanceof Error ? error : new Error(String(error)));

    // Surface the actionable message, never a raw stack trace. The full error
    // including the stack is in logs/error.log.
    const detail = isReviewError(error)
      ? `  [${error.code}] ${error.message}`
      : `  ${formatError(error)}`;

    console.error(`\n✖ Review of ${owner}/${repo}#${prNumber} failed.`);
    console.error(detail);
    console.error('\n  Full details in logs/error.log');
    logger.debug('Review failed', { error });
    process.exit(1);
  }
}

// Only run when executed directly, so the exported helpers stay importable by
// tests. Comparing resolved URLs rather than filename suffixes avoids matching
// an unrelated entry point that happens to end the same way.
const invokedDirectly =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;

if (invokedDirectly) {
  void main();
}
