# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 48/100 |
| **Files Reviewed** | 3 |
| **Critical Issues** | 0 |
| **High Priority Tests** | 12 |
| **Refactoring Opportunities** | 11 |

## 🎯 Top Recommendations

1. 🚨 **bug-risk**: Fix the todo-id generation bug in App.tsx: `nextId` is a render-scoped `let` that resets to 1 on every render, so sequential adds can produce duplicate ids. Because onToggle/onDelete match by id, this causes silent cross-item corruption (toggling or deleting the wrong todo). Replace with a ref, UUID, or an id derived inside the state updater.
   - Files: src/App.tsx

2. ⚠️ **bug-risk**: Reconcile the search feature this PR is meant to deliver: App.tsx's `search` state is never applied to filter todos, and TodoForm's text input is labeled 'Search or add todo...' while being wired only to add-on-submit inside a <form> — a user pressing Enter to search will instead create a garbage todo. Separate search input/state from the add form, and make search state in App.tsx actually filter the list (or clarify that TodoList owns filtering and remove the redundant/misleading UI).
   - Files: src/App.tsx, src/components/TodoForm.tsx, src/components/TodoList.tsx

3. ⚠️ **bug-risk**: Fix the due-date validation timezone bug in TodoForm.tsx: comparing a UTC-midnight-parsed date string against the local `new Date()` rejects 'today' as a due date for most of the day in timezones behind UTC (including Brazil). Compare calendar dates (YYYY-MM-DD strings) rather than instants.
   - Files: src/components/TodoForm.tsx

4. ⚠️ **testing**: None of the three reviewed files have any accompanying tests (0% coverage estimate across the board). Prioritize covering the core CRUD paths first — add/toggle/delete in App.tsx, both validation guards and the happy-path submit-and-reset in TodoForm.tsx, and the onToggle/onDelete callback wiring in TodoItem.tsx — since these are the highest-priority untested paths and several overlap with real bugs found above (duplicate ids, timezone validation).
   - Files: src/App.tsx, src/components/TodoForm.tsx, src/components/TodoItem.tsx

5. 📝 **accessibility**: Address recurring accessibility gaps: TodoForm's inputs have no labels/aria-labels, and TodoItem communicates priority via color alone (WCAG 1.4.1 failure) with an unlabeled checkbox and a non-descriptive Delete button. Add labels/aria-labels throughout and supplement color with text or icons for priority.
   - Files: src/components/TodoForm.tsx, src/components/TodoItem.tsx

## 📁 File Details

### 📄 `src/App.tsx`

**Quality Score:** 45/100 | **Coverage:** ~0%

#### Issues (7)
  - Line 12: `high` `nextId` is a local `let` reinitialized to 1 on every component render. Since the component re-renders on every keystroke in the search box or any filter change, calling `addTodo` twice with a render in between produces two todos with the same `id: 1`. Because `onToggle` and `onDelete` match by `t.id === id`, colliding IDs cause both todos to toggle or delete together — silent, user-reachable data corruption.
  - Line 26: `high` `filteredTodos.sort(...)` mutates the array in place and returns the same reference. Currently masked because `filteredTodos` is freshly built each render, but it is a latent bug that will surface the moment this pipeline is wrapped in `useMemo` or the filtered array is reused elsewhere.
  - Line 18: `medium` `search` state is declared and passed to `TodoList` as a prop but is never used to filter `todos` within `App.tsx`. For a PR whose purpose is adding search functionality, this either means filtering is entirely delegated to `TodoList` or the feature is incomplete/duplicated across components.

  *...and 4 more*

#### Test Gaps (10)
  - `nextId counter in addTodo() (lines 8, 13-15)` (critical priority)
  - `filteredTodos status filter, filter === 'active' branch (line 19)` (high priority)

  *...and 8 more*

#### Refactoring Opportunities (4)
  - **pattern-improvement**: The chained filters, sort, and inline priority lookup table (rebuilt per comparison) are all inlined in the component body — exactly the code this PR is growing. Extracting it into a hook consolidates the filtering concerns and hoists the static lookup table.
  - **rename**: `filter` reads as a generic noun right next to `.filter()` calls a few lines below, and doesn't match the naming convention set by its sibling `priorityFilter`.

  *...and 2 more*

---

### 📄 `src/components/TodoForm.tsx`

**Quality Score:** 43/100 | **Coverage:** ~0%

#### Issues (8)
  - Line 18: `high` `<input type="date">` produces a date-only string parsed by `new Date()` as UTC midnight, compared against `new Date()` (current local instant). For any timezone behind UTC (including Brazil, UTC-3), selecting today's date is rejected as 'in the past' for most of the day — a reproducible functional bug for a large share of users.
  - Line 31: `high` The placeholder 'Search or add todo...' implies this field searches, but it is only wired to onAdd on submit. Since it sits inside a <form>, pressing Enter after typing a search query creates a new todo containing the search text instead of filtering — a functional regression against this PR's own goal.
  - Line 8: `medium` `useState('medium')` infers `priority: string`, discarding the literal union `Todo['priority']`. The `as Todo['priority']` cast at submission (line 22) is unchecked — an invalid option added later without updating the type would silently pass through.

  *...and 5 more*

#### Test Gaps (7)
  - `handleSubmit() — if (!text.trim())` (high priority)
  - `handleSubmit() — if (dueDate && new Date(dueDate) < new Date())` (high priority)

  *...and 5 more*

#### Refactoring Opportunities (4)
  - **pattern-improvement**: Four separate useState calls hold one cohesive form-data concept and are reset together on every submit; the reset list can silently drift from the initial useState defaults as fields are added.
  - **extract-function**: The two validation checks are embedded in the event handler and can't be unit-tested without mounting the component and simulating a submit event.

  *...and 2 more*

---

### 📄 `src/components/TodoItem.tsx`

**Quality Score:** 57/100 | **Coverage:** ~0%

#### Issues (10)
  - Line 6: `medium` getPriorityColor takes `priority: string` instead of Todo['priority'], and ends in a silent default: return 'gray'. Widening to string discards the compiler's ability to catch a missing case if a new priority value is introduced elsewhere.
  - Line 17: `medium` Priority is communicated only via color (red/orange/green/gray) with no text, icon, or pattern fallback — a WCAG 1.4.1 'use of color alone' failure affecting colorblind users.
  - Line 17: `low` Hardcoded color literals ('red', 'orange', 'green', 'gray') are duplicated wherever priority is rendered instead of using theme tokens or CSS classes.

  *...and 7 more*

#### Test Gaps (6)
  - `onDelete button click handler (onClick={() => onDelete(todo.id)})` (critical priority)
  - `checkbox onChange handler (onChange={() => onToggle(todo.id)})` (high priority)

  *...and 4 more*

#### Refactoring Opportunities (3)
  - **pattern-improvement**: The function maps a closed set of values to a color using a switch with a default fallback, implying an open-ended set; a bare string parameter also means TypeScript can never confirm every case is covered.
  - **rename**: A generic 'Props' name says nothing about which component it belongs to, colliding in imports/autocomplete/error messages once multiple components exist in the same PR.

  *...and 1 more*

---

*Generated at 2026-09-29T18:00:00Z • Duration: 447011ms*
