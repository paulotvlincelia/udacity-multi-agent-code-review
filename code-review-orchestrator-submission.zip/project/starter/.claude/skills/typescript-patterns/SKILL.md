---
name: typescript-patterns
description: TypeScript-specific review - type safety, inference, discriminated unions, strict-mode gaps and the patterns that defeat the type system.
---

# TypeScript Patterns

Applies to `.ts` and `.tsx`. The question is not whether the code compiles - it is
whether the types are load-bearing or decorative.

## Type safety holes

**`any` erases checking, and it spreads.** Every property access, call and assignment
on an `any` is unchecked, and the result is `any` too. Flag each occurrence unless a
comment justifies it.

The honest replacement is `unknown` plus narrowing:

```ts
// defeats the type system
function handle(payload: any) { return payload.data.items.length; }

// forces the check the first version skipped
function handle(payload: unknown) {
  if (!isPayload(payload)) throw new TypeError('bad payload');
  return payload.data.items.length;
}
```

**Assertions are claims, not checks.** `value as Foo` tells the compiler to stop
asking; nothing verifies it at runtime. `as unknown as Foo` is a double assertion
that defeats even the compatibility check - almost always a design problem.
`<T>value` is the older syntax with the same meaning.

**Non-null assertion.** `value!` claims "not null, trust me". Fine right after a
guard the compiler cannot see; a latent crash everywhere else.

**`@ts-ignore` hides the next error too**, not just the one it was added for.
`@ts-expect-error` is strictly better: it fails when the error stops happening.

## Strict mode

Check `tsconfig.json` and read the code against what is actually enabled:

| Flag | Catches |
|---|---|
| `strictNullChecks` | `null`/`undefined` where a value is required |
| `noUncheckedIndexedAccess` | `arr[0]` typed as `T` when it may be `undefined` |
| `noImplicitAny` | parameters that silently became `any` |
| `strictFunctionTypes` | unsound parameter variance |
| `exactOptionalPropertyTypes` | `{ a?: string }` assigned an explicit `undefined` |

`noUncheckedIndexedAccess` is the one that surprises people: with it on, every array
index and record lookup is `T | undefined`, and code written before it was enabled
will not compile.

## Modelling with the type system

**Discriminated unions instead of optional grab-bags.** A type where fields are
optional because they apply to different cases cannot be narrowed:

```ts
// every field optional - the compiler cannot help
type Result = { ok?: boolean; data?: User; error?: string };

// narrowing on `status` makes the other fields exact
type Result =
  | { status: 'success'; data: User }
  | { status: 'error'; error: string };
```

**Exhaustiveness.** A `switch` over a union should end in a `never` check, so adding a
variant becomes a compile error rather than a silent fallthrough:

```ts
default: {
  const exhaustive: never = status;
  throw new Error(`unhandled: ${exhaustive}`);
}
```

**Let inference work.** Annotating what the compiler already knows adds drift without
adding safety. Annotate the boundaries - parameters, return types of exported
functions, module-level constants - and let the middle infer.

**`as const` for literal types.** Without it, `['a','b']` is `string[]` and the
literal values are lost.

**Prefer `readonly`** on parameters the function does not mutate. It documents intent
and blocks accidental mutation at compile time.

## Runtime validation at the boundary

Types vanish at runtime. Data arriving from a network response, a file, `process.env`
or `JSON.parse` is `unknown` in truth, whatever it is annotated as.

```ts
// a lie: nothing checked this
const user = await res.json() as User;

// honest: the shape is verified before it is trusted
const user = UserSchema.parse(await res.json());
```

Casting a parsed response to an interface is the single most common way a
TypeScript codebase gets a runtime `undefined is not a function`.

## Async

- A promise created and not awaited swallows its rejection - flag floating promises.
- `async` on a function with no `await` adds a microtask and misleads the reader.
- Sequential `await` in a loop over independent work should be `Promise.all`.
- `Promise.all` rejects on the first failure; `Promise.allSettled` when partial
  results are wanted. Choosing wrong loses data.
- Catching and rethrowing without adding context just lengthens the stack.

## Output

For each finding give the line, a severity, the category (`maintainability`,
`bug-risk` or `best-practice`), what the current types fail to prevent, and the
concrete change.

Weight findings by what they let through at runtime. An `any` on a network boundary
is a real risk; an `any` in a test fixture is noise.
