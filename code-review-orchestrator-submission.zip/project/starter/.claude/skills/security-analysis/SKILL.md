---
name: security-analysis
description: Security review for any source file - OWASP Top 10 patterns, hardcoded secrets, injection, broken access control and unsafe data handling. Applies to every language.
---

# Security Analysis

Vulnerabilities do not respect file extension, so this applies to every file under
review. Report what you can point at: a line, a mechanism, and a consequence.

## Hardcoded secrets

The highest-confidence finding in any review, because it needs no reasoning about
reachability - the key is already in version control, and rotating it is the only fix.

Look for string literals matching:

| Pattern | What it is |
|---|---|
| `sk-`, `sk-live-`, `sk_test_` | API keys (Anthropic, OpenAI, Stripe) |
| `ghp_`, `gho_`, `github_pat_` | GitHub tokens |
| `AKIA[0-9A-Z]{16}` | AWS access key id |
| `-----BEGIN .* PRIVATE KEY-----` | private key material |
| `mongodb://user:pass@`, `postgres://user:pass@` | credentials in a connection string |
| `password = "..."`, `secret: "..."` | assigned credentials |

Severity is `critical` when the value looks live, `high` when it is clearly a
placeholder but the pattern invites a real one later.

A secret is worse when it also travels: a key placed in a URL query string lands in
browser history, server access logs, proxy logs and `Referer` headers. Flag the
transmission separately from the storage.

## Injection

**XSS.** Untrusted input reaching a sink that parses HTML or script:

```js
element.innerHTML = userInput;              // sink
element.outerHTML = userInput;              // sink
document.write(userInput);                  // sink
eval(userInput);                            // sink
new Function(userInput);                    // sink
setTimeout(userInput, 0);                   // sink when passed a string
<a href={`javascript:${userInput}`}>        // sink
dangerouslySetInnerHTML={{__html: input}}   // sink (React)
```

The fix is almost always `textContent` instead of `innerHTML`, or a sanitizer when
markup is genuinely required.

A `javascript:` URL is a sink even when the value looks constant: it executes in the
page's origin, and inline handlers written this way bypass Content Security Policy.

**SQL and command injection.** String concatenation or interpolation building a query
or a shell command. The fix is parameterised queries and argument arrays, never
escaping.

**Path traversal.** User input reaching `readFile`, `join` or `open` without
normalising and confining to a base directory. `../` is the whole attack.

## Broken access control

The one that static patterns miss, so read for it deliberately.

- **Client-side authorization.** A flag like `isPremium`, `isAdmin` or `role` held in
  browser state and checked in browser code. Anyone can set it from the console. The
  check has to happen where the user cannot reach - on the server, per request.
- **Missing ownership check.** An endpoint that takes an id and acts on it without
  verifying the caller owns that record.
- **Trusting a client-supplied identity.** A user id read from the request body
  rather than from the authenticated session.
- **Unprotected state change.** A mutation reachable without authentication at all.

For any paid or privileged feature, ask: what stops a user who edits the JavaScript?
If the answer is nothing, that is `critical`.

## Unsafe data handling

- Unvalidated input crossing a trust boundary - no type, length, format or range check.
- Deserializing untrusted data into objects.
- Secrets or personal data written to logs.
- Errors returned to the caller with stack traces or internal paths.
- Weak crypto: MD5 or SHA-1 for passwords, `Math.random()` for tokens, a hardcoded IV.
- Missing integrity check on data that crossed a boundary and came back.

## Dependencies and transport

- Requests to `http://` where `https://` exists.
- Disabled certificate validation (`rejectUnauthorized: false`, `verify=False`).
- A CORS policy of `*` on an endpoint that carries credentials.

## Output

For each finding give the line, a severity of `critical`, `high`, `medium`, `low`
or `info`, category `security`, what an attacker gains, and the concrete fix.

Do not report the absence of a security control that is irrelevant to the file - a
pure formatting helper does not need authorization. Precision is what makes the rest
of the report worth reading.
