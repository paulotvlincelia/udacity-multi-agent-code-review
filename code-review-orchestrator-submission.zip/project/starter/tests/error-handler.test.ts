import { describe, it, expect, vi, afterEach } from 'vitest';
import { withRetry, withTimeout, ReviewError, ErrorCodes, isReviewError } from '../src/utils/index.js';

/**
 * C36-C41: retry and timeout.
 *
 * Fake timers keep the exponential backoff assertions instant - a real run of
 * 1s + 2s + 4s would make the suite slow enough that nobody runs it.
 */

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

/** Advance fake timers until a promise settles, however many sleeps it awaits. */
async function runWithFakeTimers<T>(work: () => Promise<T>): Promise<T> {
  const promise = work();
  // Attach a catch immediately so a rejection while we pump timers is not
  // reported as unhandled.
  const settled = promise.then(
    (value) => ({ ok: true as const, value }),
    (error) => ({ ok: false as const, error })
  );

  for (let i = 0; i < 50; i++) {
    await vi.advanceTimersByTimeAsync(10_000);
  }

  const result = await settled;
  if (result.ok) return result.value;
  throw result.error;
}

describe('withRetry', () => {
  it('applies exponential backoff of 1s 2s 4s', async () => {
    vi.useFakeTimers();
    const delays: number[] = [];
    const realSetTimeout = globalThis.setTimeout;
    vi.spyOn(globalThis, 'setTimeout').mockImplementation(((fn: () => void, ms?: number) => {
      delays.push(ms ?? 0);
      return realSetTimeout(fn, ms);
    }) as typeof setTimeout);

    const alwaysFails = vi.fn().mockRejectedValue(new Error('boom'));

    await expect(runWithFakeTimers(() => withRetry(alwaysFails, 4, 1000))).rejects.toThrow();

    // 4 attempts means 3 sleeps: 1000, 2000, 4000 - each plus jitter under 100ms.
    expect(delays).toHaveLength(3);
    expect(delays[0]).toBeGreaterThanOrEqual(1000);
    expect(delays[0]).toBeLessThan(1100);
    expect(delays[1]).toBeGreaterThanOrEqual(2000);
    expect(delays[1]).toBeLessThan(2100);
    expect(delays[2]).toBeGreaterThanOrEqual(4000);
    expect(delays[2]).toBeLessThan(4100);
  });

  it('adds jitter under 100ms', async () => {
    vi.useFakeTimers();
    const delays: number[] = [];
    const realSetTimeout = globalThis.setTimeout;
    vi.spyOn(globalThis, 'setTimeout').mockImplementation(((fn: () => void, ms?: number) => {
      delays.push(ms ?? 0);
      return realSetTimeout(fn, ms);
    }) as typeof setTimeout);

    // Two runs of one sleep each. Jitter makes the same attempt number differ,
    // which is what desynchronises clients that failed together.
    const fail = () => Promise.reject(new Error('boom'));
    await expect(runWithFakeTimers(() => withRetry(fail, 2, 1000))).rejects.toThrow();
    await expect(runWithFakeTimers(() => withRetry(fail, 2, 1000))).rejects.toThrow();

    expect(delays).toHaveLength(2);
    for (const delay of delays) {
      expect(delay).toBeGreaterThanOrEqual(1000);
      expect(delay).toBeLessThan(1100);
    }
    expect(delays[0]).not.toBe(delays[1]);
  });

  it('throws RETRY_EXHAUSTED when retries run out', async () => {
    vi.useFakeTimers();
    const alwaysFails = vi.fn().mockRejectedValue(new Error('upstream down'));

    const error = await runWithFakeTimers(() =>
      withRetry(alwaysFails, 3, 10).then(
        () => null,
        (e: unknown) => e
      )
    );

    expect(isReviewError(error)).toBe(true);
    expect((error as ReviewError).code).toBe(ErrorCodes.RETRY_EXHAUSTED);
    expect((error as ReviewError).message).toContain('upstream down');
    expect(alwaysFails).toHaveBeenCalledTimes(3);
  });

  it('returns the value when a later attempt succeeds', async () => {
    vi.useFakeTimers();
    let calls = 0;
    const flaky = vi.fn(async () => {
      calls += 1;
      if (calls < 2) throw new Error('transient');
      return 'recovered';
    });

    const value = await runWithFakeTimers(() => withRetry(flaky, 3, 10));

    expect(value).toBe('recovered');
    expect(flaky).toHaveBeenCalledTimes(2);
  });
});

describe('withTimeout', () => {
  it('times out with AGENT_TIMEOUT and timeoutMs metadata', async () => {
    vi.useFakeTimers();
    const neverSettles = () => new Promise<string>(() => {});

    const error = await runWithFakeTimers(() =>
      withTimeout(neverSettles, 5000, 'took too long').then(
        () => null,
        (e: unknown) => e
      )
    );

    expect(isReviewError(error)).toBe(true);
    expect((error as ReviewError).code).toBe(ErrorCodes.AGENT_TIMEOUT);
    expect((error as ReviewError).message).toBe('took too long');
    expect((error as ReviewError).metadata).toEqual({ timeoutMs: 5000 });
  });

  it('returns the value when fn finishes before the deadline', async () => {
    const fast = async () => 'done';
    await expect(withTimeout(fast, 5000)).resolves.toBe('done');
  });

  it('propagates the original error when fn rejects before the deadline', async () => {
    // A failure inside fn must surface as itself, not be masked as a timeout.
    const fails = async () => {
      throw new Error('real failure');
    };
    await expect(withTimeout(fails, 5000)).rejects.toThrow('real failure');
  });
});
