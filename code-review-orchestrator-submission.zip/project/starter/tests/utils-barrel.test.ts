import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import * as utils from '../src/utils/index.js';
import { CodeReviewOrchestrator } from '../src/orchestrator.js';

/**
 * C42: the utils barrel, and the integration the rubric asks for.
 *
 * The starter ships these exports commented out with a TODO. Re-enabling them is
 * Task 4.4, and the rubric additionally requires the utilities to be *used*
 * somewhere - an exported-but-unused helper satisfies neither.
 */

describe('utils barrel', () => {
  it('utils barrel exports error handler and rate limiter', () => {
    // Every symbol Task 4.4 asks to uncomment.
    for (const name of [
      'logger',
      'ReportGenerator',
      'RateLimiter',
      'globalRateLimiter',
      'withRateLimit',
      'DEFAULT_RATE_LIMITS',
      'ReviewError',
      'ErrorCodes',
      'withRetry',
      'withTimeout',
      'isReviewError',
      'formatError'
    ] as const) {
      expect(utils[name], `utils must export ${name}`).toBeDefined();
    }
  });

  it('exported error utilities are callable and typed', () => {
    expect(utils.withRetry).toBeTypeOf('function');
    expect(utils.withTimeout).toBeTypeOf('function');
    expect(utils.isReviewError(new utils.ReviewError('x', 'TEST'))).toBe(true);
    expect(utils.isReviewError(new Error('x'))).toBe(false);
    expect(utils.formatError(new utils.ReviewError('boom', 'TEST'))).toBe('[TEST] boom');
  });

  it('barrel re-exports with .js specifiers', () => {
    const barrel = readFileSync(new URL('../src/utils/index.ts', import.meta.url), 'utf8');
    const relative = [...barrel.matchAll(/from\s+'(\.[^']*)'/g)].map((m) => m[1]!);

    expect(relative.length).toBeGreaterThan(0);
    for (const specifier of relative) {
      expect(specifier, `${specifier} must end in .js`).toMatch(/\.js$/);
    }
  });
});

describe('utilities are integrated, not merely exported', () => {
  it('orchestrator wraps the SDK call in withRetry and withTimeout', () => {
    // The rubric asks for the utilities to be integrated "where appropriate".
    // Asserted against the source because the wrapping is structural: calling
    // reviewPullRequest would hit the network.
    const source = readFileSync(new URL('../src/orchestrator.ts', import.meta.url), 'utf8');

    expect(source, 'orchestrator must import withRetry').toMatch(/withRetry/);
    expect(source, 'orchestrator must import withTimeout').toMatch(/withTimeout/);

    // Both must actually wrap the query, not just be imported.
    expect(source).toMatch(/withTimeout\(/);
    expect(source).toMatch(/withRetry\(/);
  });

  it('orchestrator applies the rate limiter around the review', () => {
    const source = readFileSync(new URL('../src/orchestrator.ts', import.meta.url), 'utf8');

    expect(source).toMatch(/rateLimiter\.acquire\(/);
    // release() must be in a finally, or a failed review leaks a slot and the
    // limiter deadlocks after maxConcurrent failures.
    expect(source).toMatch(/finally\s*\{[^}]*rateLimiter\.release\(\)/s);
  });

  it('retry policy is configurable and defaults are sane', () => {
    const orchestrator = new CodeReviewOrchestrator({ maxRetries: 5, retryDelayMs: 50 });
    const applied = orchestrator as unknown as { maxRetries: number; retryDelayMs: number };

    expect(applied.maxRetries).toBe(5);
    expect(applied.retryDelayMs).toBe(50);

    const defaults = new CodeReviewOrchestrator() as unknown as {
      maxRetries: number;
      retryDelayMs: number;
    };
    expect(defaults.maxRetries).toBeGreaterThanOrEqual(1);
    expect(defaults.retryDelayMs).toBeGreaterThan(0);
  });

  it('main.ts uses the error formatting helpers rather than raw errors', () => {
    // The rubric asks for user-friendly messages, not stack traces.
    const source = readFileSync(new URL('../src/main.ts', import.meta.url), 'utf8');

    expect(source).toMatch(/isReviewError|formatError/);
    expect(source).toMatch(/ReportGenerator/);
  });
});
