import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';

/**
 * C18: the Claude Skills the code-quality agent invokes.
 *
 * Whether a skill's content actually reaches the model depends on the query
 * setting settingSources: ['project'] - that is C19, asserted against the
 * orchestrator options.
 */

/** The two skills this project adds. */
const NEW_SKILLS = ['typescript-patterns', 'security-analysis'];

/** Every skill the code-quality prompt can invoke, including the starter's. */
const ALL_SKILLS = [...NEW_SKILLS, 'javascript-best-practices'];

const skillPath = (name: string) =>
  new URL(`../.claude/skills/${name}/SKILL.md`, import.meta.url).pathname;

describe('claude skills', () => {
  it('both new skills exist with valid frontmatter', () => {
    for (const name of NEW_SKILLS) {
      const path = skillPath(name);
      expect(existsSync(path), `${name}/SKILL.md must exist`).toBe(true);

      const contents = readFileSync(path, 'utf8');
      const frontmatter = /^---\n([\s\S]*?)\n---/.exec(contents);
      expect(frontmatter, `${name} must open with YAML frontmatter`).not.toBeNull();

      const body = frontmatter![1]!;
      expect(body, `${name} frontmatter needs a name`).toMatch(/^name:\s*\S+/m);
      expect(body, `${name} frontmatter needs a description`).toMatch(/^description:\s*\S+/m);
    }
  });

  it('every invokable skill resolves by its directory name', () => {
    // The Skill tool resolves by directory, so the directory is what the prompt
    // must name. `name:` in frontmatter is optional - the starter's provided
    // skill omits it - but when present it must agree with the directory or the
    // two identities diverge.
    for (const name of ALL_SKILLS) {
      const path = skillPath(name);
      expect(existsSync(path), `${name}/SKILL.md must exist`).toBe(true);

      const declared = /^name:\s*(\S+)/m.exec(readFileSync(path, 'utf8'))?.[1];
      if (declared !== undefined) {
        expect(declared, `${name} frontmatter name disagrees with its directory`).toBe(name);
      }
    }
  });

  it('every invokable skill has a description', () => {
    // The description is what the model uses to decide a skill is relevant.
    for (const name of ALL_SKILLS) {
      const contents = readFileSync(skillPath(name), 'utf8');
      expect(contents, `${name} needs a description`).toMatch(/^description:\s*\S+/m);
    }
  });

  it('security-analysis covers the vulnerability classes in the fixture', () => {
    // The PR under review in the deliverables contains a hardcoded key, XSS via
    // innerHTML, a key in a URL and client-side authorization. The skill has to
    // give the agent something to recognise each one by.
    const contents = readFileSync(skillPath('security-analysis'), 'utf8').toLowerCase();
    for (const topic of ['hardcoded secret', 'innerhtml', 'javascript:', 'client-side authorization']) {
      expect(contents, `security-analysis must cover ${topic}`).toContain(topic);
    }
  });
});
