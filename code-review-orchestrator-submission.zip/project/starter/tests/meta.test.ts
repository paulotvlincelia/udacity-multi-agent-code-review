import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/**
 * C48, C50, C66, C67: properties of the codebase itself.
 *
 * These guard failures that leave everything else looking green - an empty test
 * body, an unjustified `any`, a module that grew a responsibility it should not
 * have.
 */

const ROOT = new URL('..', import.meta.url).pathname;
const SRC = join(ROOT, 'src');
const TESTS = join(ROOT, 'tests');

/** Files the starter provides and this project does not own. */
const PROVIDED = ['src/types/', 'src/utils/logger.ts', 'src/utils/report-generator.ts'];

function walk(dir: string, extension = '.ts'): string[] {
  if (!existsSync(dir)) return [];
  return readdirSync(dir).flatMap((entry) => {
    const full = join(dir, entry);
    return statSync(full).isDirectory() ? walk(full, extension) : full.endsWith(extension) ? [full] : [];
  });
}

const relative = (path: string) => path.slice(ROOT.length);
const isOurs = (path: string) => !PROVIDED.some((p) => relative(path).startsWith(p));

describe('test suite integrity', () => {
  it('no test has an empty body', () => {
    // Vitest passes an empty `it()`, so a suite can be green while asserting
    // nothing - the failure this whole file exists to catch.
    const offenders: string[] = [];

    for (const file of walk(TESTS)) {
      // Strip comments before scanning, or a prose example of an empty test -
      // like the one describing this very check - is reported as a real one.
      const contents = readFileSync(file, 'utf8')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/^\s*\/\/[^\n]*$/gm, '');

      // Matches a test whose arrow body is empty or comment-only.
      const empties = contents.matchAll(
        /\b(it|test)(?:\.\w+)?\s*\(\s*['"`][^'"`]+['"`]\s*,[^)]*?\(\s*\)\s*=>\s*\{([\s\S]*?)\}\s*\)/g
      );

      for (const match of empties) {
        const body = (match[2] ?? '')
          .replace(/\/\*[\s\S]*?\*\//g, '')
          .replace(/\/\/[^\n]*/g, '')
          .trim();
        if (body.length === 0) {
          offenders.push(`${relative(file)}: ${match[1]}(${match[0].slice(0, 60)}...)`);
        }
      }
    }

    expect(offenders, 'these tests assert nothing').toEqual([]);
  });

  it('integration test with octocat Hello-World is documented', () => {
    // The rubric asks for evidence the integration case was considered.
    const orchestratorTest = readFileSync(join(TESTS, 'orchestrator.test.ts'), 'utf8');
    expect(orchestratorTest).toMatch(/it\.skip/);
    expect(orchestratorTest).toContain('Hello-World');
  });
});

describe('type safety', () => {
  it('every any is justified by a comment', () => {
    // `any` is not banned outright - it is banned silently. An occurrence needs
    // a reason on the same line or the one above.
    const offenders: string[] = [];

    for (const file of walk(SRC).filter(isOurs)) {
      const lines = readFileSync(file, 'utf8').split('\n');

      lines.forEach((line, index) => {
        // `: any`, `as any`, `<any>`, `any[]` - but not `anything` or `Company`.
        if (!/(:\s*any\b|\bas\s+any\b|<any>|\bany\[\])/.test(line)) return;

        const hasComment = line.includes('//') || (lines[index - 1] ?? '').trim().startsWith('//') ||
          (lines[index - 1] ?? '').trim().startsWith('*');

        if (!hasComment) offenders.push(`${relative(file)}:${index + 1}: ${line.trim()}`);
      });
    }

    expect(offenders, 'each of these needs a justifying comment or a narrower type').toEqual([]);
  });
});

describe('module separation', () => {
  it('prompts and mcp config live in their own modules', () => {
    // Agent files declare; they must not carry prompt text inline.
    for (const file of walk(join(SRC, 'agents'))) {
      const contents = readFileSync(file, 'utf8');
      const hasLongTemplate = /`[^`]{300,}`/.test(contents);
      expect(hasLongTemplate, `${relative(file)} appears to inline a prompt`).toBe(false);
    }

    // The orchestrator composes; it must not define server configuration.
    const orchestrator = readFileSync(join(SRC, 'orchestrator.ts'), 'utf8');
    expect(orchestrator, 'orchestrator must import the MCP config, not declare it').not.toMatch(
      /command:\s*'npx'/
    );
    expect(orchestrator).toContain("from './config/mcp.config.js'");
  });

  it('every relative import in src carries a .js extension', () => {
    // "type": "module" with "module": "ESNext": tsc does not rewrite
    // specifiers, so a missing extension resolves at build time and fails at
    // runtime.
    const offenders: string[] = [];

    for (const file of walk(SRC).filter(isOurs)) {
      const contents = readFileSync(file, 'utf8');
      for (const match of contents.matchAll(/from\s+'(\.[^']*)'/g)) {
        const specifier = match[1]!;
        if (!specifier.endsWith('.js')) offenders.push(`${relative(file)}: ${specifier}`);
      }
    }

    expect(offenders, 'these specifiers will fail at runtime').toEqual([]);
  });
});

describe('build output', () => {
  it('build emits dist/main.js', () => {
    // Asserted only when a build has run, so the suite stays green on a clean
    // checkout. `npm run build` is the proof that settles the claim itself.
    const dist = join(ROOT, 'dist', 'main.js');
    if (!existsSync(dist)) {
      expect(existsSync(join(ROOT, 'src', 'main.ts'))).toBe(true);
      return;
    }
    expect(readFileSync(dist, 'utf8').length).toBeGreaterThan(0);
  });
});
