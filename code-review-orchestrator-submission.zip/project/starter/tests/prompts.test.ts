import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import {
  buildOrchestratorPrompt,
  CODE_QUALITY_ANALYZER_PROMPT,
  TEST_COVERAGE_ANALYZER_PROMPT,
  REFACTORING_SUGGESTER_PROMPT
} from '../src/prompts/index.js';

/**
 * C11-C17, C20: prompt content.
 *
 * The rubric grades prompts on what they say, so these assertions look for the
 * concepts by name. They are deliberately case-insensitive and substring-based:
 * the claim is that the prompt covers the topic, not that it uses one phrasing.
 */

const AGENT_PROMPTS: Array<[name: string, prompt: string, schemaFields: string[]]> = [
  ['code-quality', CODE_QUALITY_ANALYZER_PROMPT, ['overallScore', 'severity', 'category']],
  ['test-coverage', TEST_COVERAGE_ANALYZER_PROMPT, ['coverageEstimate', 'untestedPaths', 'hasTests']],
  ['refactoring', REFACTORING_SUGGESTER_PROMPT, ['suggestions', 'impact', 'benefits']]
];

const ORCHESTRATOR_PROMPT = buildOrchestratorPrompt('octocat', 'Hello-World', 42, 10);

describe('orchestrator prompt', () => {
  it('orchestrator prompt instructs fetch then delegate', () => {
    const prompt = ORCHESTRATOR_PROMPT.toLowerCase();

    // Stage 1: fetch PR data through the GitHub MCP tools.
    expect(prompt).toContain('github mcp');
    expect(prompt).toContain('pull request');

    // Stage 2: delegate explicitly. Without an imperative naming each agent the
    // model analyses the code itself, which produces a populated report while
    // failing the criteria that grade subagent spawning.
    expect(prompt).toContain('use the task tool');
    for (const subagent of [
      'code-quality-analyzer',
      'test-coverage-analyzer',
      'refactoring-suggester'
    ]) {
      expect(prompt, `orchestrator must name ${subagent}`).toContain(subagent);
    }

    // The fetch stage must come before the delegate stage.
    const fetchAt = prompt.indexOf('github mcp');
    const delegateAt = prompt.indexOf('use the task tool');
    expect(fetchAt).toBeLessThan(delegateAt);
  });

  it('orchestrator prompt carries the PR coordinates it was built with', () => {
    expect(ORCHESTRATOR_PROMPT).toContain('octocat');
    expect(ORCHESTRATOR_PROMPT).toContain('Hello-World');
    expect(ORCHESTRATOR_PROMPT).toContain('42');
  });

  it('orchestrator prompt tells the model how to degrade a failed subagent', () => {
    // All three sections are required by the schema, so a failure has to produce
    // a valid object rather than an omission.
    expect(ORCHESTRATOR_PROMPT).toContain('Analysis failed:');
    expect(ORCHESTRATOR_PROMPT.toLowerCase()).toContain('never omit a section');
  });
});

describe('agent prompts', () => {
  it('code quality prompt names security and performance', () => {
    const prompt = CODE_QUALITY_ANALYZER_PROMPT.toLowerCase();
    expect(prompt).toContain('security');
    expect(prompt).toContain('performance');
  });

  it('test coverage prompt names assertions and gaps', () => {
    const prompt = TEST_COVERAGE_ANALYZER_PROMPT.toLowerCase();
    expect(prompt).toContain('assertion');
    expect(prompt).toContain('untested');
  });

  it('refactoring prompt requires before and after', () => {
    const prompt = REFACTORING_SUGGESTER_PROMPT.toLowerCase();
    expect(prompt).toContain('before');
    expect(prompt).toContain('after');
    // The pair must be demanded as code, not as prose description.
    expect(prompt).toContain('the code itself');
  });

  it('every agent prompt references its schema fields', () => {
    for (const [name, prompt, fields] of AGENT_PROMPTS) {
      for (const field of fields) {
        expect(prompt, `${name} prompt must name the ${field} field`).toContain(field);
      }
    }
  });

  it('every agent prompt states severity criteria', () => {
    // Principle 3 of the course's five: what makes an issue high versus low.
    for (const [name, prompt] of AGENT_PROMPTS) {
      const lower = prompt.toLowerCase();
      const hasCriteriaSection = /## (severity|prioritising|impact) criteria|## prioritising the gaps/.test(lower);
      expect(hasCriteriaSection, `${name} prompt needs a severity/priority criteria section`).toBe(true);
    }
  });

  it('every agent prompt warns that enum values are fixed', () => {
    // A value outside the enum makes Zod reject the object and empties the report.
    for (const [name, prompt] of AGENT_PROMPTS) {
      expect(prompt, `${name} prompt must pin the enum values`).toContain(
        'Use only the enum values listed above'
      );
    }
  });

  it('code quality prompt routes skills by file extension', () => {
    const prompt = CODE_QUALITY_ANALYZER_PROMPT;
    // security-analysis on everything; the language skills by extension.
    expect(prompt).toContain('Skill "security-analysis"');
    expect(prompt).toContain('Skill "typescript-patterns"');
    expect(prompt).toContain('Skill "javascript-best-practices"');
    expect(prompt.toLowerCase()).toContain('every** file');
  });

  it('every agent prompt carries skills guidance', () => {
    // Principle 4 of the five the course asks for. This check used to cover the
    // code-quality prompt alone, and the other two had the Skill tool in their
    // tools array with nothing in the prompt telling them to use it - an agent
    // holding a tool it is never instructed to reach for.
    const prompts = [
      ['code quality', CODE_QUALITY_ANALYZER_PROMPT],
      ['test coverage', TEST_COVERAGE_ANALYZER_PROMPT],
      ['refactoring', REFACTORING_SUGGESTER_PROMPT]
    ] as const;

    for (const [label, prompt] of prompts) {
      expect(prompt, `${label} prompt must have a skills section`).toContain('Using Claude Skills');

      // Named skills, not a vague instruction to "use skills" - the agent has to
      // know which ones exist.
      for (const skill of ['security-analysis', 'typescript-patterns', 'javascript-best-practices']) {
        expect(prompt, `${label} prompt must name Skill "${skill}"`).toContain(`Skill "${skill}"`);
      }
    }
  });

  it('named skills all exist on disk', () => {
    // A prompt naming a skill that is not installed sends the agent after
    // nothing. The directory name is the invocation key.
    const skillsDir = new URL('../.claude/skills/', import.meta.url);

    for (const skill of ['security-analysis', 'typescript-patterns', 'javascript-best-practices']) {
      const path = new URL(`${skill}/SKILL.md`, skillsDir);
      expect(existsSync(path), `.claude/skills/${skill}/SKILL.md must exist`).toBe(true);
    }
  });
});

describe('prompts barrel', () => {
  it('prompts barrel re-exports all four with .js imports', () => {
    const barrel = readFileSync(new URL('../src/prompts/index.ts', import.meta.url), 'utf8');
    const relativeImports = [...barrel.matchAll(/from\s+'(\.[^']*)'/g)].map((m) => m[1]!);

    expect(relativeImports).toHaveLength(4);
    for (const specifier of relativeImports) {
      expect(specifier, `${specifier} must end in .js`).toMatch(/\.js$/);
    }
  });
});
