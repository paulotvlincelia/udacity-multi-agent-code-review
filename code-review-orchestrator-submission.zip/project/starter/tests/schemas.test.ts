import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema,
  ReviewReportSchema,
  CodeQualityResultJSONSchema,
  TestCoverageResultJSONSchema,
  RefactoringSuggestionJSONSchema,
  ReviewReportJSONSchema
} from '../src/types/index.js';

/**
 * C47: the four test groups Task 5.1 enumerates - valid data, invalid data,
 * edge cases, and the JSON Schema export.
 *
 * These schemas are the contract between the agent prompts and the report
 * generator: a value outside an enum is rejected wholesale, which empties the
 * report rather than degrading it.
 */

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const validCodeQuality = {
  file: 'src/payment.ts',
  issues: [
    {
      line: 42,
      severity: 'critical' as const,
      category: 'security' as const,
      description: 'Hardcoded API key committed to source',
      suggestion: 'Read it from process.env and rotate the exposed key'
    }
  ],
  overallScore: 75,
  summary: 'One critical credential exposure.'
};

const validTestCoverage = {
  file: 'src/payment.ts',
  hasTests: true,
  testFiles: ['tests/payment.test.ts'],
  untestedPaths: [
    {
      type: 'branch' as const,
      location: 'charge() refund path',
      priority: 'high' as const,
      reasoning: 'The refund branch has no assertion, so a regression is silent',
      suggestedTest: 'Call charge() with a negative amount and assert it throws'
    }
  ],
  coverageEstimate: 60,
  summary: 'Happy path covered, refund path not.'
};

const validRefactoring = {
  file: 'src/payment.ts',
  suggestions: [
    {
      type: 'extract-function' as const,
      location: 'charge() lines 20-45',
      impact: 'medium' as const,
      description: 'The validation block is a nameable unit',
      before: 'if (!amount || amount < 0) { throw new Error("bad"); }',
      after: 'assertValidAmount(amount);',
      benefits: 'The rule becomes reusable and testable on its own'
    }
  ],
  summary: 'One extraction worth doing.'
};

const validReport = {
  pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
  fileReviews: [
    {
      file: 'src/payment.ts',
      codeQuality: validCodeQuality,
      testCoverage: validTestCoverage,
      refactorings: validRefactoring
    }
  ],
  summary: {
    totalFiles: 1,
    overallScore: 75,
    criticalIssues: 1,
    highPriorityTests: 1,
    refactoringOpportunities: 1
  },
  recommendations: [
    {
      priority: 'critical' as const,
      category: 'security',
      description: 'Rotate and externalise the committed credential',
      files: ['src/payment.ts']
    }
  ],
  metadata: {
    analyzedAt: '2026-09-28T10:30:00Z',
    duration: 15420,
    agentVersions: { 'code-quality-analyzer': '1.0.0' }
  }
};

// ---------------------------------------------------------------------------
// Group 1: valid data parses
// ---------------------------------------------------------------------------

describe('valid data parses for every schema', () => {
  const cases: Array<[name: string, schema: z.ZodTypeAny, value: unknown]> = [
    ['CodeQualityResult', CodeQualityResultSchema, validCodeQuality],
    ['TestCoverageResult', TestCoverageResultSchema, validTestCoverage],
    ['RefactoringSuggestion', RefactoringSuggestionSchema, validRefactoring],
    ['ReviewReport', ReviewReportSchema, validReport]
  ];

  it('valid data parses for every schema', () => {
    for (const [name, schema, value] of cases) {
      expect(() => schema.parse(value), `${name} should accept its fixture`).not.toThrow();
    }
  });

  it('parse returns the data unchanged', () => {
    expect(CodeQualityResultSchema.parse(validCodeQuality)).toEqual(validCodeQuality);
    expect(ReviewReportSchema.parse(validReport)).toEqual(validReport);
  });
});

// ---------------------------------------------------------------------------
// Group 2: invalid data is rejected
// ---------------------------------------------------------------------------

describe('invalid data throws ZodError', () => {
  it('invalid data throws ZodError', () => {
    const invalid: Array<[reason: string, schema: z.ZodTypeAny, value: unknown]> = [
      // Wrong types
      ['line as a string', CodeQualityResultSchema, { ...validCodeQuality, issues: [{ ...validCodeQuality.issues[0], line: '42' }] }],
      ['score as a string', CodeQualityResultSchema, { ...validCodeQuality, overallScore: '75' }],
      ['hasTests as a string', TestCoverageResultSchema, { ...validTestCoverage, hasTests: 'yes' }],
      ['testFiles not an array', TestCoverageResultSchema, { ...validTestCoverage, testFiles: 'tests/a.ts' }],

      // Missing required fields
      ['missing file', CodeQualityResultSchema, { issues: [], overallScore: 100, summary: 'x' }],
      ['missing summary', RefactoringSuggestionSchema, { file: 'a.ts', suggestions: [] }],
      ['missing metadata', ReviewReportSchema, { ...validReport, metadata: undefined }],

      // Invalid enum values - the failure mode that empties a report
      ['severity "blocker"', CodeQualityResultSchema, { ...validCodeQuality, issues: [{ ...validCodeQuality.issues[0], severity: 'blocker' }] }],
      ['category "typo"', CodeQualityResultSchema, { ...validCodeQuality, issues: [{ ...validCodeQuality.issues[0], category: 'typo' }] }],
      ['untested type "module"', TestCoverageResultSchema, { ...validTestCoverage, untestedPaths: [{ ...validTestCoverage.untestedPaths[0], type: 'module' }] }],
      ['refactor type "inline"', RefactoringSuggestionSchema, { ...validRefactoring, suggestions: [{ ...validRefactoring.suggestions[0], type: 'inline' }] }],
      ['impact "critical"', RefactoringSuggestionSchema, { ...validRefactoring, suggestions: [{ ...validRefactoring.suggestions[0], impact: 'critical' }] }],

      // priority has no 'info' level, unlike severity - an easy confusion
      ['priority "info"', TestCoverageResultSchema, { ...validTestCoverage, untestedPaths: [{ ...validTestCoverage.untestedPaths[0], priority: 'info' }] }],

      // Out of range
      ['score above 100', CodeQualityResultSchema, { ...validCodeQuality, overallScore: 101 }],
      ['score below 0', CodeQualityResultSchema, { ...validCodeQuality, overallScore: -1 }],
      ['coverage above 100', TestCoverageResultSchema, { ...validTestCoverage, coverageEstimate: 150 }]
    ];

    for (const [reason, schema, value] of invalid) {
      expect(() => schema.parse(value), `${reason} must be rejected`).toThrow(z.ZodError);
    }
  });

  it('safeParse reports the offending field path', () => {
    const result = CodeQualityResultSchema.safeParse({
      ...validCodeQuality,
      overallScore: 500
    });

    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues[0]?.path).toEqual(['overallScore']);
    }
  });

  it('severity accepts info but priority does not', () => {
    // The two scales differ by exactly one member, which is why prompts pin
    // the literal values rather than describing them.
    const withInfoSeverity = {
      ...validCodeQuality,
      issues: [{ ...validCodeQuality.issues[0]!, severity: 'info' as const }]
    };
    expect(() => CodeQualityResultSchema.parse(withInfoSeverity)).not.toThrow();

    const withInfoPriority = {
      ...validTestCoverage,
      untestedPaths: [{ ...validTestCoverage.untestedPaths[0]!, priority: 'info' }]
    };
    expect(() => TestCoverageResultSchema.parse(withInfoPriority)).toThrow(z.ZodError);
  });
});

// ---------------------------------------------------------------------------
// Group 3: edge cases
// ---------------------------------------------------------------------------

describe('edge cases: empty arrays and score bounds', () => {
  it('edge cases: empty arrays and score bounds', () => {
    // An empty findings array is a legitimate result - clean code.
    expect(() =>
      CodeQualityResultSchema.parse({ ...validCodeQuality, issues: [], overallScore: 100 })
    ).not.toThrow();

    expect(() =>
      TestCoverageResultSchema.parse({ ...validTestCoverage, untestedPaths: [], testFiles: [] })
    ).not.toThrow();

    expect(() =>
      RefactoringSuggestionSchema.parse({ ...validRefactoring, suggestions: [] })
    ).not.toThrow();

    // Both score bounds are inclusive.
    for (const score of [0, 100]) {
      expect(() =>
        CodeQualityResultSchema.parse({ ...validCodeQuality, overallScore: score })
      ).not.toThrow();
      expect(() =>
        TestCoverageResultSchema.parse({ ...validTestCoverage, coverageEstimate: score })
      ).not.toThrow();
    }
  });

  it('a report with no file reviews is structurally valid', () => {
    // An empty PR produces this. Structurally fine; the deliverables check is
    // what rejects it as a submitted report.
    expect(() =>
      ReviewReportSchema.parse({
        ...validReport,
        fileReviews: [],
        summary: { ...validReport.summary, totalFiles: 0 }
      })
    ).not.toThrow();
  });

  it('agentVersions accepts any string-valued record', () => {
    expect(() =>
      ReviewReportSchema.parse({
        ...validReport,
        metadata: { ...validReport.metadata, agentVersions: {} }
      })
    ).not.toThrow();

    // Values must be strings - a number is rejected.
    expect(() =>
      ReviewReportSchema.parse({
        ...validReport,
        metadata: { ...validReport.metadata, agentVersions: { agent: 1 } }
      })
    ).toThrow(z.ZodError);
  });
});

// ---------------------------------------------------------------------------
// Group 4: JSON Schema export for SDK structured outputs
// ---------------------------------------------------------------------------

describe('zodToJsonSchema marks required properties', () => {
  const exported: Array<[name: string, schema: Record<string, unknown>]> = [
    ['CodeQualityResult', CodeQualityResultJSONSchema],
    ['TestCoverageResult', TestCoverageResultJSONSchema],
    ['RefactoringSuggestion', RefactoringSuggestionJSONSchema],
    ['ReviewReport', ReviewReportJSONSchema]
  ];

  it('zodToJsonSchema marks required properties', () => {
    for (const [name, schema] of exported) {
      expect(schema.type, `${name} must be an object schema`).toBe('object');
      expect(schema.properties, `${name} needs properties`).toBeTypeOf('object');
      expect(Array.isArray(schema.required), `${name} needs a required array`).toBe(true);
    }

    // Spot-check that required lists the fields the agents must supply.
    expect(CodeQualityResultJSONSchema.required).toEqual(
      expect.arrayContaining(['file', 'issues', 'overallScore', 'summary'])
    );
    expect(ReviewReportJSONSchema.required).toEqual(
      expect.arrayContaining(['pullRequest', 'fileReviews', 'summary', 'recommendations', 'metadata'])
    );
  });

  it('exported schemas are JSON-serialisable', () => {
    // The SDK sends these over the wire; a circular ref or a function would
    // fail at request time rather than here.
    for (const [name, schema] of exported) {
      expect(() => JSON.stringify(schema), `${name} must serialise`).not.toThrow();
    }
  });

  it('enum constraints survive the conversion', () => {
    // The enums are what keep an agent from inventing a severity level, so they
    // have to reach the model through the JSON Schema, not just through Zod.
    const serialised = JSON.stringify(CodeQualityResultJSONSchema);
    for (const value of ['critical', 'high', 'medium', 'low', 'info']) {
      expect(serialised, `severity "${value}" must appear in the JSON Schema`).toContain(value);
    }
    for (const value of ['security', 'performance', 'maintainability', 'bug-risk']) {
      expect(serialised, `category "${value}" must appear in the JSON Schema`).toContain(value);
    }
  });
});
