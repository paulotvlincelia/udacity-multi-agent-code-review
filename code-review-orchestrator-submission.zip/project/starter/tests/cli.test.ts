import { describe, it, expect } from 'vitest';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { writeReports } from '../src/main.js';
import { ReviewReportSchema, type ReviewReport } from '../src/types/index.js';

/**
 * C30-C35: CLI behaviour.
 *
 * The validation checks run the real entry point in a child process, because
 * the claim is about the exit code and the message a user sees - neither is
 * observable from inside the same process once main() calls process.exit.
 */

const SRC_MAIN = new URL('../src/main.ts', import.meta.url).pathname;
const DIST_MAIN = new URL('../dist/main.js', import.meta.url).pathname;

/**
 * Prefer the compiled entry point: `node dist/main.js` starts in about 0.1s
 * against roughly 1.3s for tsx, and this file spawns it a dozen times.
 * Falls back to tsx so the suite still runs before a build.
 *
 * The fallback invokes node_modules/.bin/tsx directly rather than going through
 * `npx tsx`. npx consults the registry before it trusts the local install, so
 * in a freshly unpacked copy with no dist/ it prints "the following package
 * was not found and will be installed" onto the stream these tests assert
 * against, and every spawn waits on the network. That is precisely the
 * situation an evaluator unzipping the submission is in.
 */
const TSX_BIN = new URL('../node_modules/.bin/tsx', import.meta.url).pathname;
const useDist = existsSync(DIST_MAIN);
const [COMMAND, BASE_ARGS] = useDist
  ? ['node', [DIST_MAIN]]
  : existsSync(TSX_BIN)
    ? [TSX_BIN, [SRC_MAIN]]
    : ['npx', ['tsx', SRC_MAIN]];

interface RunResult {
  status: number;
  output: string;
}

/**
 * Run the CLI with a controlled environment and capture its exit.
 *
 * The child runs from a scratch directory, not the project root. main.ts calls
 * dotenv.config(), which reads the project's .env from disk regardless of the
 * env we pass - so running in place would silently reintroduce the very
 * variables a test is trying to withhold, and the CLI would sail past the
 * validation gate into a real API call.
 */
function runCli(args: string[], env: Record<string, string | undefined> = {}): RunResult {
  const childEnv: Record<string, string> = {
    PATH: process.env.PATH ?? '',
    // Defaults to a HOME with no .claude/.credentials.json, so the session
    // probe finds nothing unless a test opts in. Otherwise the developer's own
    // session would mask the no-credential path entirely.
    HOME: mkdtempSync(join(tmpdir(), 'cli-home-'))
  };
  for (const [key, value] of Object.entries(env)) {
    if (value !== undefined) childEnv[key] = value;
  }

  const scratch = mkdtempSync(join(tmpdir(), 'cli-run-'));
  try {
    const output = execFileSync(COMMAND, [...BASE_ARGS, ...args], {
      cwd: scratch,
      env: childEnv,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      // A validation path should exit in well under a second. Anything slower
      // means the CLI reached the network, which is itself the bug.
      timeout: 20_000
    });
    return { status: 0, output };
  } catch (error) {
    const e = error as { status?: number; stdout?: string; stderr?: string };
    return { status: e.status ?? 1, output: `${e.stdout ?? ''}${e.stderr ?? ''}` };
  } finally {
    rmSync(scratch, { recursive: true, force: true });
  }
}

describe('CLI argument validation', () => {
  it('exits 1 with usage when args are missing', () => {
    for (const args of [[], ['owner'], ['owner', 'repo']]) {
      const { status, output } = runCli(args);
      expect(status, `args ${JSON.stringify(args)} should exit 1`).toBe(1);
      expect(output).toContain('Usage:');
    }
  });

  it('rejects every non positive integer PR number', () => {
    // Number() would accept all of these; the CLI must not.
    for (const pr of ['abc', '0', '-1', '1.5', '', ' 1 ']) {
      const { status, output } = runCli(['octocat', 'Hello-World', pr]);
      expect(status, `PR "${pr}" should exit 1`).toBe(1);
      expect(output.toLowerCase()).toMatch(/invalid pull request number|missing required arguments/);
    }
  });

  it('accepts a valid positive integer PR number', () => {
    // Passes argument validation and stops at the next gate. Auth is supplied
    // so the stop is the model check, which proves the number was accepted and
    // that validation runs in the documented order.
    const { status, output } = runCli(['octocat', 'Hello-World', '42'], {
      ANTHROPIC_API_KEY: 'sk-ant-NOT_A_REAL_KEY_fixture'
    });

    expect(status).toBe(1);
    expect(output).not.toContain('Invalid pull request number');
    expect(output).toContain('ANTHROPIC_MODEL');
  });
});

describe('CLI environment validation', () => {
  it('exits 1 naming both auth options when none present', () => {
    // No API key, no AWS keys, and a HOME with no CLI session: nothing to use.
    const { status, output } = runCli(['octocat', 'Hello-World', '1']);

    expect(status, 'no credential at all must exit 1').toBe(1);
    expect(output).toContain('No authentication method is configured');
    expect(output).toContain('ANTHROPIC_API_KEY');
    expect(output).toContain('AWS_ACCESS_KEY_ID');
    expect(output).toContain('claude login');
  });

  it('accepts an inherited CLI session when one exists', () => {
    // The third credential path: no env vars, but a session on disk.
    const fakeHome = mkdtempSync(join(tmpdir(), 'cli-home-session-'));
    // The probe looks for the CLI's config directory; the credential itself is
    // platform-specific (Keychain on macOS) and not a stable interface.
    mkdirSync(join(fakeHome, '.claude'), { recursive: true });

    try {
      const { status, output } = runCli(['octocat', 'Hello-World', '1'], { HOME: fakeHome });

      expect(output).toContain('🔐 Using inherited Claude CLI session');
      // Passes the auth gate and stops at the next one.
      expect(output).toContain('ANTHROPIC_MODEL');
      expect(status).toBe(1);
    } finally {
      rmSync(fakeHome, { recursive: true, force: true });
    }
  });

  it('exits 1 when ANTHROPIC_MODEL is unset', () => {
    const { status, output } = runCli(['octocat', 'Hello-World', '1'], {
      ANTHROPIC_API_KEY: 'sk-ant-NOT_A_REAL_KEY_fixture'
    });
    expect(status).toBe(1);
    expect(output).toContain('ANTHROPIC_MODEL is not set');
  });

  it('exits 1 when Bedrock is selected without AWS_REGION', () => {
    const { status, output } = runCli(['octocat', 'Hello-World', '1'], {
      AWS_ACCESS_KEY_ID: 'AKIAEXAMPLE',
      AWS_SECRET_ACCESS_KEY: 'secret',
      ANTHROPIC_MODEL: 'us.anthropic.claude-sonnet-4-5-20250929-v1:0'
    });
    expect(status).toBe(1);
    expect(output).toContain('AWS_REGION');
  });

  it('logs which authentication method is in use', () => {
    const anthropic = runCli(['octocat', 'Hello-World', '1'], { ANTHROPIC_API_KEY: 'sk-ant-NOT_A_REAL_KEY_fixture' });
    expect(anthropic.output).toContain('🔐 Using Anthropic API authentication');

    const bedrock = runCli(['octocat', 'Hello-World', '1'], {
      AWS_ACCESS_KEY_ID: 'AKIAEXAMPLE',
      AWS_SECRET_ACCESS_KEY: 'secret',
      AWS_REGION: 'us-east-1'
    });
    expect(bedrock.output).toContain('🔐 Using AWS Bedrock authentication');
  });
});

describe('report writing', () => {
  /** Minimal report that satisfies the schema. */
  function sampleReport(): ReviewReport {
    const report = {
      pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
      fileReviews: [
        {
          file: 'src/app.js',
          codeQuality: {
            file: 'src/app.js',
            issues: [
              {
                line: 4,
                severity: 'critical' as const,
                category: 'security' as const,
                description: 'Hardcoded API key',
                suggestion: 'Move it to an environment variable'
              }
            ],
            overallScore: 75,
            summary: 'One critical issue.'
          },
          testCoverage: {
            file: 'src/app.js',
            hasTests: false,
            testFiles: [],
            untestedPaths: [
              {
                type: 'function' as const,
                location: 'addTodo()',
                priority: 'high' as const,
                reasoning: 'No assertion covers the empty-input guard',
                suggestedTest: "Call addTodo() with '' and assert nothing is appended"
              }
            ],
            coverageEstimate: 0,
            summary: 'No tests found.'
          },
          refactorings: {
            file: 'src/app.js',
            suggestions: [
              {
                type: 'modernize' as const,
                location: 'line 3',
                impact: 'low' as const,
                description: 'Use const',
                before: 'let apiKey = "x";',
                after: 'const apiKey = process.env.API_KEY;',
                benefits: 'Signals the binding never changes'
              }
            ],
            summary: 'One modernization.'
          }
        }
      ],
      summary: {
        totalFiles: 1,
        overallScore: 75,
        criticalIssues: 1,
        highPriorityTests: 1,
        refactoringOpportunities: 1
      },
      recommendations: [
        {
          priority: 'critical' as const,
          category: 'security',
          description: 'Remove the hardcoded credential',
          files: ['src/app.js']
        }
      ],
      metadata: {
        analyzedAt: new Date().toISOString(),
        duration: 1234,
        agentVersions: { 'code-quality-analyzer': '1.0.0' }
      }
    };
    // Fail loudly here rather than in a downstream assertion if the fixture drifts.
    return ReviewReportSchema.parse(report);
  }

  it('writes six report files on success', () => {
    const scratch = mkdtempSync(join(tmpdir(), 'review-reports-'));
    const previousCwd = process.cwd();
    process.chdir(scratch);

    try {
      const written = writeReports(sampleReport(), 'octocat', 'Hello-World', 1);

      // Three formats, each under both naming conventions.
      expect(written).toHaveLength(6);
      for (const name of [
        'octocat_Hello-World_1.json',
        'octocat_Hello-World_1.md',
        'octocat_Hello-World_1.html',
        'report.json',
        'report.md',
        'report.html'
      ]) {
        expect(written.some((p) => p.endsWith(name)), `${name} must be written`).toBe(true);
      }

      // The JSON must be valid and still satisfy the schema after a round trip.
      const json = JSON.parse(readFileSync(join(scratch, 'reports', 'report.json'), 'utf8'));
      expect(ReviewReportSchema.safeParse(json).success).toBe(true);

      // The other two formats must carry the analysis, not an empty shell.
      const markdown = readFileSync(join(scratch, 'reports', 'report.md'), 'utf8');
      expect(markdown).toContain('src/app.js');
      expect(markdown).toContain('75');

      // The provided HTML generator renders the summary and the top
      // recommendations, not per-issue detail - assert what it does carry.
      const html = readFileSync(join(scratch, 'reports', 'report.html'), 'utf8');
      expect(html).toContain('<!DOCTYPE html>');
      expect(html).toContain('Remove the hardcoded credential');
      expect(html).toContain('75');
    } finally {
      process.chdir(previousCwd);
      rmSync(scratch, { recursive: true, force: true });
    }
  });

  it('an empty review does not overwrite an existing generic report', () => {
    // Regression: octocat/Hello-World#1 changes only a README, so the review is
    // valid but has no fileReviews. Writing report.{ext} unconditionally
    // replaced a dense report with that empty one - a silent downgrade of the
    // deliverable an evaluator is most likely to open.
    const scratch = mkdtempSync(join(tmpdir(), 'review-reports-'));
    const previousCwd = process.cwd();
    process.chdir(scratch);

    try {
      // A real analysis lands first and claims the generic name.
      writeReports(sampleReport(), 'octocat', 'Hello-World', 1);
      const before = readFileSync(join(scratch, 'reports', 'report.json'), 'utf8');

      const empty = ReviewReportSchema.parse({
        ...sampleReport(),
        pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 2 },
        fileReviews: [],
        summary: {
          totalFiles: 0,
          overallScore: 0,
          criticalIssues: 0,
          highPriorityTests: 0,
          refactoringOpportunities: 0
        },
        recommendations: []
      });
      const written = writeReports(empty, 'octocat', 'Hello-World', 2);

      // The per-PR file is still produced: it is addressed by name and
      // overwrites only itself, so the run remains auditable.
      expect(written).toHaveLength(3);
      for (const name of [
        'octocat_Hello-World_2.json',
        'octocat_Hello-World_2.md',
        'octocat_Hello-World_2.html'
      ]) {
        expect(written.some((p) => p.endsWith(name)), `${name} must be written`).toBe(true);
      }
      expect(written.some((p) => p.endsWith('report.json'))).toBe(false);

      // The dense report survived untouched.
      expect(readFileSync(join(scratch, 'reports', 'report.json'), 'utf8')).toBe(before);
      expect(JSON.parse(before).fileReviews).toHaveLength(1);

      // And the empty one really is on disk under its own name.
      const emptyOnDisk = JSON.parse(
        readFileSync(join(scratch, 'reports', 'octocat_Hello-World_2.json'), 'utf8')
      );
      expect(emptyOnDisk.fileReviews).toHaveLength(0);
    } finally {
      process.chdir(previousCwd);
      rmSync(scratch, { recursive: true, force: true });
    }
  });
});
