import { describe, it, expect, vi } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/**
 * C1-C4: MCP server configuration shape and secret hygiene.
 *
 * The rubric grades the literal contents of these configs - transport type,
 * command, args and the env var mapping - so the assertions here are literal too.
 */

const SRC_DIR = new URL('../src', import.meta.url).pathname;

/**
 * Re-import the config with a specific GITHUB_TOKEN in the environment.
 *
 * The config reads process.env at module scope, so the module registry has to be
 * reset between loads or the second call would see the first call's value.
 */
async function loadConfigWith(token: string | undefined) {
  const previous = process.env.GITHUB_TOKEN;
  if (token === undefined) {
    delete process.env.GITHUB_TOKEN;
  } else {
    process.env.GITHUB_TOKEN = token;
  }
  vi.resetModules();
  const mod = await import('../src/config/mcp.config.js');
  process.env.GITHUB_TOKEN = previous;
  return mod.mcpServersConfig;
}

describe('MCP configuration', () => {
  it('github MCP server config shape', async () => {
    const config = await loadConfigWith('ghp_NOT_A_REAL_TOKEN_fixture');
    expect(config.github.type).toBe('stdio');
    expect(config.github.command).toBe('npx');
    expect(config.github.args).toEqual(['-y', '@modelcontextprotocol/server-github']);
  });

  it('maps GITHUB_TOKEN to GITHUB_PERSONAL_ACCESS_TOKEN', async () => {
    const withToken = await loadConfigWith('ghp_NOT_A_REAL_TOKEN_fixture');
    expect(withToken.github.env.GITHUB_PERSONAL_ACCESS_TOKEN).toBe('ghp_NOT_A_REAL_TOKEN_fixture');

    // Absent token must become '', never undefined: the stdio transport rejects
    // undefined env values, and the repo under review is public anyway.
    const withoutToken = await loadConfigWith(undefined);
    expect(withoutToken.github.env.GITHUB_PERSONAL_ACCESS_TOKEN).toBe('');
  });

  it('eslint MCP server config shape', async () => {
    const config = await loadConfigWith('ghp_NOT_A_REAL_TOKEN_fixture');
    expect(config.eslint.type).toBe('stdio');
    expect(config.eslint.command).toBe('npx');
    expect(config.eslint.args).toEqual(['-y', '@eslint/mcp@latest']);
  });
});

describe('secret hygiene', () => {
  it('no hardcoded credentials in source', () => {
    // Anthropic keys, GitHub PATs (classic, OAuth, fine-grained).
    const secretPatterns = [/sk-ant-[A-Za-z0-9]/, /ghp_[A-Za-z0-9]/, /gho_[A-Za-z0-9]/, /github_pat_[A-Za-z0-9]/];

    const walk = (dir: string): string[] =>
      readdirSync(dir).flatMap((entry) => {
        const full = join(dir, entry);
        return statSync(full).isDirectory() ? walk(full) : full.endsWith('.ts') ? [full] : [];
      });

    const offenders = walk(SRC_DIR).filter((file) => {
      const contents = readFileSync(file, 'utf8');
      return secretPatterns.some((pattern) => pattern.test(contents));
    });

    expect(offenders).toEqual([]);
  });
});
