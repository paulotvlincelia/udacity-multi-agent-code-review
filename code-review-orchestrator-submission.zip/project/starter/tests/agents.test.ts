import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import {
  codeQualityAnalyzer,
  testCoverageAnalyzer,
  refactoringSuggester
} from '../src/agents/index.js';

/**
 * C5-C10: subagent definitions.
 *
 * The rubric grades these field by field, so the table below drives most of the
 * assertions: a new agent added without its row would not be covered.
 */

const AGENTS: Array<[name: string, definition: AgentDefinition]> = [
  ['code-quality-analyzer', codeQualityAnalyzer],
  ['test-coverage-analyzer', testCoverageAnalyzer],
  ['refactoring-suggester', refactoringSuggester]
];

/** Tools that could modify the repository or execute code. Analysis needs none. */
const WRITE_OR_EXEC_TOOLS = ['Write', 'Edit', 'NotebookEdit', 'Bash', 'BashOutput', 'KillShell'];

describe('subagent definitions', () => {
  it('all three agent files export a definition', () => {
    expect(AGENTS).toHaveLength(3);
    for (const [name, definition] of AGENTS) {
      expect(definition, `${name} should be an object`).toBeTypeOf('object');
    }
  });

  it('every agent has non-empty description and prompt', () => {
    for (const [name, definition] of AGENTS) {
      expect(definition.description.trim().length, `${name} description`).toBeGreaterThan(0);
      expect(definition.prompt.trim().length, `${name} prompt`).toBeGreaterThan(0);
    }
  });

  it('every agent sets model to inherit', () => {
    // 'inherit' keeps severity calibration consistent across the three agents and
    // makes ANTHROPIC_MODEL the single source of the model.
    for (const [name, definition] of AGENTS) {
      expect(definition.model, `${name} model`).toBe('inherit');
    }
  });

  it('code-quality-analyzer includes the Skill tool', () => {
    // Named specifically by the course's Phase 1-3 checkpoint.
    expect(codeQualityAnalyzer.tools).toContain('Skill');
  });

  it('no agent has write or exec tools', () => {
    // Least privilege, named as a principle in the course checkpoint.
    for (const [name, definition] of AGENTS) {
      const forbidden = (definition.tools ?? []).filter((tool) =>
        WRITE_OR_EXEC_TOOLS.includes(tool)
      );
      expect(forbidden, `${name} must not carry write or exec tools`).toEqual([]);
    }
  });

  it('agents barrel re-exports all three with .js imports', async () => {
    // Two halves to this claim: the barrel exports the three agents, and its
    // specifiers carry .js. Asserting only the second left the first unproven.
    const barrel = await import('../src/agents/index.js');

    expect(barrel.codeQualityAnalyzer).toBe(codeQualityAnalyzer);
    expect(barrel.testCoverageAnalyzer).toBe(testCoverageAnalyzer);
    expect(barrel.refactoringSuggester).toBe(refactoringSuggester);

    // And the registry keyed by subagent_type, which is what the SDK receives.
    expect(Object.keys(barrel.agents).sort()).toEqual([
      'code-quality-analyzer',
      'refactoring-suggester',
      'test-coverage-analyzer'
    ]);

    const source = readFileSync(new URL('../src/agents/index.ts', import.meta.url), 'utf8');
    const relativeImports = [...source.matchAll(/from\s+'(\.[^']*)'/g)].map((m) => m[1]!);

    expect(relativeImports.length).toBeGreaterThan(0);
    for (const specifier of relativeImports) {
      // "type": "module" + "module": "ESNext" means a missing extension fails at
      // runtime, and tsc does not rewrite specifiers.
      expect(specifier, `${specifier} must end in .js`).toMatch(/\.js$/);
    }
  });

  it('refactoring-suggester is not given Glob', () => {
    // AC 6b: it operates on the file it was handed, so file discovery is not
    // its job. Least privilege applies per agent, not just as a blanket rule.
    expect(refactoringSuggester.tools).not.toContain('Glob');
    // The other two need it: one to find related files, one to find test files.
    expect(codeQualityAnalyzer.tools).toContain('Glob');
    expect(testCoverageAnalyzer.tools).toContain('Glob');
  });
});
