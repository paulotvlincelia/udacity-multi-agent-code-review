import { describe, it, expect, vi } from 'vitest';
import { RateLimiter } from '../src/utils/index.js';

/**
 * C43-C46: sliding window rate limiting.
 *
 * requestHistory is private, so the assertions go through getStatus() and
 * observable blocking behaviour rather than reaching into internals.
 */

/** Push a record dated `agoMs` in the past, to set up a window state. */
function seedRecord(limiter: RateLimiter, agoMs: number, tokens: number): void {
  const history = (limiter as unknown as { requestHistory: Array<{ timestamp: number; tokens: number }> })
    .requestHistory;
  history.push({ timestamp: Date.now() - agoMs, tokens });
}

describe('RateLimiter sliding window', () => {
  it('prunes records older than 60 seconds', () => {
    const limiter = new RateLimiter();

    seedRecord(limiter, 61_000, 500); // outside the window
    seedRecord(limiter, 59_000, 700); // inside the window

    // getStatus prunes before reporting.
    const status = limiter.getStatus();

    expect(status.requestsInWindow).toBe(1);
    expect(status.tokensInWindow).toBe(700);
  });

  it('canProceed enforces all three limits', () => {
    // Each limit is checked in isolation: a generous config with one tight axis.
    const concurrent = new RateLimiter({ maxConcurrent: 1, maxRequestsPerMinute: 99, maxTokensPerMinute: 1e6 });
    (concurrent as unknown as { activeRequests: number }).activeRequests = 1;
    expect(concurrent.canProceed(10), 'maxConcurrent reached').toBe(false);

    const perMinute = new RateLimiter({ maxConcurrent: 99, maxRequestsPerMinute: 2, maxTokensPerMinute: 1e6 });
    seedRecord(perMinute, 1_000, 10);
    seedRecord(perMinute, 1_000, 10);
    expect(perMinute.canProceed(10), 'maxRequestsPerMinute reached').toBe(false);

    const tokens = new RateLimiter({ maxConcurrent: 99, maxRequestsPerMinute: 99, maxTokensPerMinute: 1000 });
    seedRecord(tokens, 1_000, 900);
    expect(tokens.canProceed(200), 'maxTokensPerMinute would be exceeded').toBe(false);
    expect(tokens.canProceed(100), 'exactly at the token limit is allowed').toBe(true);

    const clear = new RateLimiter({ maxConcurrent: 5, maxRequestsPerMinute: 50, maxTokensPerMinute: 1e6 });
    expect(clear.canProceed(1000), 'no limit reached').toBe(true);
  });

  it('acquire blocks past maxConcurrent until release', async () => {
    const limiter = new RateLimiter({ maxConcurrent: 1, maxRequestsPerMinute: 99, maxTokensPerMinute: 1e6 });

    await limiter.acquire(100);
    expect(limiter.getStatus().activeRequests).toBe(1);

    // The second acquire has no slot, so it parks on the wait queue.
    let secondResolved = false;
    const second = limiter.acquire(100).then(() => {
      secondResolved = true;
    });

    await Promise.resolve();
    expect(secondResolved, 'second acquire must not resolve while the slot is held').toBe(false);

    // release() shifts the queued resolver, which lets it through.
    limiter.release();
    await second;

    expect(secondResolved).toBe(true);
    expect(limiter.getStatus().activeRequests).toBe(1);
  });

  it('acquire records the request and its tokens', async () => {
    const limiter = new RateLimiter({ maxConcurrent: 5, maxRequestsPerMinute: 50, maxTokensPerMinute: 100_000 });

    await limiter.acquire(2500);
    const status = limiter.getStatus();

    expect(status.requestsInWindow).toBe(1);
    expect(status.tokensInWindow).toBe(2500);
    expect(status.activeRequests).toBe(1);
    expect(status.availableRequests).toBe(49);
    expect(status.availableTokens).toBe(97_500);
  });

  it('release updates the last record with the actual token count', async () => {
    // Guards the pre-existing TS18048 site: the element is checked, not the length.
    const limiter = new RateLimiter();

    await limiter.acquire(1000);
    limiter.release(4321);

    expect(limiter.getStatus().tokensInWindow).toBe(4321);
    expect(limiter.getStatus().activeRequests).toBe(0);
  });

  it('waitForRateLimit waits for the window then proceeds', async () => {
    // The request-per-minute limit is full with a record that expires shortly,
    // so acquire must wait rather than reject, then go through.
    const limiter = new RateLimiter({
      maxConcurrent: 5,
      maxRequestsPerMinute: 1,
      maxTokensPerMinute: 1e6
    });

    // Aged to 59.9s: inside the window now, outside it a moment later.
    seedRecord(limiter, 59_900, 10);
    expect(limiter.canProceed(10), 'window is full before waiting').toBe(false);

    const startedAt = Date.now();
    await limiter.acquire(10);

    // It slept rather than spinning or failing.
    expect(Date.now() - startedAt).toBeGreaterThanOrEqual(90);
    expect(limiter.getStatus().activeRequests).toBe(1);
  });

  it('waitForRateLimit breaks when the window is empty', async () => {
    // Branch: history empty means the block is concurrency, not rate, and
    // waiting on the clock would never clear it. Without the break this hangs.
    const limiter = new RateLimiter({
      maxConcurrent: 5,
      maxRequestsPerMinute: 0, // can never be satisfied by waiting
      maxTokensPerMinute: 1e6
    });

    expect(limiter.canProceed(10)).toBe(false);

    // Resolves because the loop breaks on an empty history.
    await expect(limiter.acquire(10)).resolves.toBeUndefined();
  });

  it('waitForRateLimit caps a single sleep at five seconds', async () => {
    // Branch: the wait is Math.min(..., 5000), so a record that expires in 60s
    // must not produce a single 60s sleep.
    const limiter = new RateLimiter({
      maxConcurrent: 5,
      maxRequestsPerMinute: 1,
      maxTokensPerMinute: 1e6
    });
    seedRecord(limiter, 0, 10); // expires a full window from now

    const delays: number[] = [];
    const realSetTimeout = globalThis.setTimeout;
    const spy = vi
      .spyOn(globalThis, 'setTimeout')
      .mockImplementation(((fn: () => void, ms?: number) => {
        delays.push(ms ?? 0);
        // Fire immediately so the test does not actually wait.
        return realSetTimeout(fn, 0);
      }) as typeof setTimeout);

    // Let it loop a few times, then stop it by clearing the window.
    const acquired = limiter.acquire(10);
    await new Promise((resolve) => realSetTimeout(resolve, 30));
    (limiter as unknown as { requestHistory: unknown[] }).requestHistory = [];
    await acquired;

    spy.mockRestore();

    expect(delays.length).toBeGreaterThan(0);
    for (const delay of delays) {
      expect(delay, 'each sleep is floored at 100ms').toBeGreaterThanOrEqual(100);
      expect(delay, 'each sleep is capped at 5000ms').toBeLessThanOrEqual(5000);
    }
  });

  it('release on an empty limiter does not throw or go negative', () => {
    const limiter = new RateLimiter();
    expect(() => limiter.release(500)).not.toThrow();
    expect(limiter.getStatus().activeRequests).toBe(0);
  });
});
