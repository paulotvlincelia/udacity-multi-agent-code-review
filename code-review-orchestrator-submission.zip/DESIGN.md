# Design Decisions

This document answers the questions the project guide poses across Phases 1–4.
Each answer reflects what the implementation actually does; where a claim about the
SDK or a package is checkable, the evidence is cited.

---

## Phase 1 — MCP Configuration

### Research questions: the GitHub MCP server

**Which package provides it?**

`@modelcontextprotocol/server-github`, launched with `npx -y`.

Worth recording: `npm view` reports this package as deprecated ("Package no longer
supported", last version 2025.4.8). It still installs and works, and it is the
package the project specifies, so it is what this implementation uses. The
successor is `github/github-mcp-server`, a Go binary distributed separately.

**Which environment variable does it expect for authentication?**

`GITHUB_PERSONAL_ACCESS_TOKEN`.

**How is `GITHUB_TOKEN` from `.env` mapped to it?**

Through the server's `env` block in [src/config/mcp.config.ts](project/starter/src/config/mcp.config.ts):

```ts
env: { GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '' }
```

The `|| ''` is load-bearing. The token is optional — it raises the GitHub rate limit
from 60 to 5000 requests per hour and unlocks private repositories — but the stdio
transport rejects an `undefined` env value outright. Without the fallback, a missing
token fails the connection instead of degrading to anonymous access against a public
repository.

### Research questions: the ESLint MCP server

**Which package provides it?** `@eslint/mcp@latest` (currently 0.3.13), also via `npx -y`.

**Does it require authentication?** No. It runs locally over the checked-out files,
so its `env` is `{}`.

---

## Phase 2 — Subagents

### Understanding agent definitions

**What properties does an `AgentDefinition` have?**

From the installed SDK's type declarations (`@anthropic-ai/claude-agent-sdk@0.1.56`,
`sdk.d.ts`):

| Field | Type | Required |
|---|---|---|
| `description` | `string` | yes |
| `prompt` | `string` | yes |
| `tools` | `string[]` | no — omitted inherits every tool from the parent |
| `disallowedTools` | `string[]` | no |
| `model` | `'sonnet' \| 'opus' \| 'haiku' \| 'inherit'` | no |

**What does `model: 'inherit'` mean?**

The subagent runs on the same model as the orchestrator rather than choosing its own.
Three reasons it is the right setting here:

1. **Consistency.** The three agents grade severity on the same scales. Different
   models calibrate differently, so mixing them would make a `high` from one agent
   mean something other than a `high` from another within the same report.
2. **Single source of the model.** `ANTHROPIC_MODEL` decides, and a reviewer running
   this project with their own model gets it applied throughout.
3. **The field cannot express anything else.** It accepts only those four literals —
   a full model id like `claude-sonnet-4-5-20250929` is not assignable. `'inherit'`
   is how a specific model reaches a subagent at all.

**What is the `description` field for?**

It is what the orchestrator reads when choosing which subagent to invoke. The `Task`
tool takes a `subagent_type`, which is a key in the `agents` record, and the model
picks that key from the descriptions.

So the descriptions are written as *when to use this*, not *what this is*. Code
quality and refactoring both read source files, so each description states the
boundary explicitly — one finds defects, the other improves code that already works.
A vague description produces a report where two agents answer the same question and
nobody answers the third.

**What tools can agents use?**

Built-in tools (`Read`, `Grep`, `Glob`, `Skill`, `Task`, `WebSearch`, and others) plus
whatever the connected MCP servers expose. Omitting `tools` inherits everything from
the parent; listing them restricts.

### Task 2.1 — Code Quality Analyzer

**What tools does it need?** `Read` to open the file, `Grep` to search for patterns
(secrets, `innerHTML`, `eval`), `Glob` to locate related files, `Skill` to load domain
expertise.

It does **not** get `Write`, `Edit` or `Bash`. The Phase 1–3 checkpoint names least
privilege as a principle, and analysis never needs to modify or execute anything.
Withholding the tools removes the possibility rather than trusting the prompt.

**How does it leverage Claude Skills?** By routing on file extension, with one skill
that always runs:

| File | Skill |
|---|---|
| any extension | `security-analysis` |
| `.ts`, `.tsx` | `typescript-patterns` |
| `.js`, `.jsx` | `javascript-best-practices` |

`security-analysis` runs on everything because vulnerabilities do not respect file
type — and the fixture proves the point, since `index.html` turned out to carry a
critical finding of its own.

**A non-obvious requirement.** Listing `Skill` in `tools` is not enough. The SDK only
reads `.claude/skills/` when the query sets `settingSources: ['project']`; the type's
own documentation states that when the option is omitted, "no filesystem settings are
loaded (SDK isolation mode)".

This was verified with a probe skill containing a marker token:

```
settingSources=undefined   | tools=[Skill] | marker found: false
settingSources=['project'] | tools=[Skill] | marker found: true
```

The failure mode is silent and misleading: the model still calls the `Skill` tool, the
trace shows the invocation, and the report still populates — but the skill's content
never entered the context.

**What should the description say?** When to use the agent, and how it differs from
the refactoring agent. See above.

### Task 2.2 — Test Coverage Analyzer

**How can an AI estimate test coverage without running the tests?**

Structurally, by correspondence rather than execution:

1. Locate candidate test files by convention (`*.test.*`, `*.spec.*`, `__tests__/`,
   `test_*.py`) using `Glob`.
2. Enumerate every exported function, class and branch in the source.
3. For each symbol, `Grep` the test files for an assertion on its observable result.
   An import is not coverage; a symbol named in a test title is not coverage.
4. Report the ratio conservatively.

The field is named `coverageEstimate`, not `coverage`, and the prompt instructs the
agent to resolve doubt downward. An optimistic estimate is worse than no estimate: it
tells a team to stop looking. Error paths in particular are almost never covered even
when the happy path is.

**What makes a test suggestion actionable rather than generic?**

Naming the call, the input and the assertion.

> Generic: "Add unit tests for this function. Test the edge cases."
>
> Actionable: "Call `addTodo()` with the input value set to `''` and assert that
> `todoList.children.length` is unchanged" — with reasoning: the empty-input guard on
> line 8 has no assertion, so a regression that drops it would pass.

The schema enforces the shape by splitting `location`, `reasoning`, `priority` and
`suggestedTest` into separate fields, so a suggestion missing the *why* is visibly
incomplete.

**What tools does it need?** `Read`, `Glob`, `Grep`, `Skill`. `Glob` matters more here
than for the other agents, because discovering the test files is step one of the
method rather than an optimisation.

### Task 2.3 — Refactoring Suggester

**What types of refactoring should it look for?**

The five members of the schema's enum: `extract-function`, `rename`, `modernize`,
`simplify`, `pattern-improvement`. The prompt lists the literals so the model cannot
invent a sixth category that Zod would then reject.

**How does this differ from code quality analysis?**

By the question each one asks. Code quality asks *is this wrong?* and returns an issue
with a severity. Refactoring asks *could this be better?* and returns a suggestion
with an impact and a before/after pair.

`innerHTML = userInput` is a critical security issue, not a refactoring suggestion. A
`for` loop that reads better as `.map()` is a low-impact `modernize` suggestion, not an
issue. Where the two overlap — confusing code is both `maintainability` and
`simplify` — the rule is that anything carrying a risk of being *wrong* belongs to
code quality.

This boundary is why they are separate agents rather than one prompt. Merged, a model
prioritises one lens and treats the others as afterthoughts, which reproduces exactly
the "limited scope" weakness of manual review that the system exists to fix.

**What tools does it need?** `Read`, `Grep`, `Skill`. No `Glob` — it works on the file
it was handed.

---

## Phase 3 — Orchestrator

### Task 3.1 — The orchestrator prompt

**Which MCP tool fetches pull request data?**

Confirmed from a live run against `octocat/Hello-World#1` (the tool names were logged
from the actual message stream):

```
mcp__github__get_pull_request         PR metadata
mcp__github__get_pull_request_files   changed files and patches
mcp__github__get_file_contents        full file contents at a ref
```

The flow is `get_pull_request_files` to learn what changed, then `get_file_contents`
for each file worth reviewing. The patch alone is not enough: judging whether
`innerHTML = text` is exploitable requires seeing where `text` comes from, which is
usually outside the diff.

**Should subagents run in parallel or sequentially, and why?**

**Parallel**, per file. The three are independent — none consumes another's output,
and all three read the same input — so serialising them would triple latency for no
benefit.

The real constraint is not logical but the API rate limit. Fan-out is
`files × 3`, which is why the project has a rate limiter with `maxConcurrent: 5`. The
prompt asks for the three calls on a file to be issued together; the SDK runtime does
the actual scheduling.

**How should the orchestrator handle a subagent failure?**

Degrade, do not abort. If the test-coverage agent fails on one file, the quality and
refactoring findings for that file are still worth having.

The schema constrains *how* it degrades. `fileReviews[].testCoverage` is required, not
optional, so omitting it fails validation and loses the entire report — the opposite
of graceful. The orchestrator therefore fills the failed section with a valid object
that declares the failure:

```ts
{ file, hasTests: false, testFiles: [], untestedPaths: [],
  coverageEstimate: 0, summary: "Analysis failed: <reason>" }
```

The "reports contain populated data" requirement is still met: the field holds real
information, and the information is that the analysis failed.

**What should the final output structure look like?** `ReviewReportSchema`, defined in
[src/types/report-types.ts](project/starter/src/types/report-types.ts).

### Task 3.2 — Implementing the orchestrator class

**What should be passed to the `agents` option?**

A `Record<string, AgentDefinition>` whose keys are exactly the `subagent_type` values
the prompt names: `code-quality-analyzer`, `test-coverage-analyzer`,
`refactoring-suggester`. Renaming a key without updating the prompt silently stops
that agent from ever being invoked.

**What tools should be in `allowedTools`?**

```ts
['Task', 'Read', 'Grep', 'Glob', 'mcp__github', 'mcp__eslint']
```

`Task` is the critical one — it is what spawns subagents, and without it the
orchestrator can only analyse the code itself.

The MCP servers are enabled by prefix rather than by enumerating tool names. The
naming pattern is `mcp__<server>__<tool>`, so `mcp__github` admits the whole server
and does not break when the server adds or renames a tool between versions.

**Which model, and should it be hardcoded?**

`process.env.ANTHROPIC_MODEL`, never hardcoded. A hardcoded model ignores the
reviewer's configuration and contradicts the requirement that credentials and
configuration come from the environment. Subagents inherit it via `model: 'inherit'`.

**What is a reasonable `maxTurns`?**

**120**, with `maxFiles` capped at **3**. Both numbers came from failures, not from
estimation.

Each file costs roughly four turns — one content fetch plus three delegations — on
top of two or three for the PR and its file list. The first attempt used 80 turns and
a 10-file cap, and a five-file pull request exposed why that was wrong: all fifteen
delegations completed successfully, and then the aggregation step produced no
structured output at all. The expensive work succeeded and the report was lost.

Capping files was the right fix rather than only raising turns, because the failure
was in assembling a report from fifteen analyses, not in producing them. Raising the
turn budget alone postpones the same wall.

Measured at the current settings: a one-file PR in 122s with 3 delegations, and two
three-file PRs in 398s and 476s with 9 delegations each. None truncated.

`MAX_FILES` raises the cap for a larger pull request; raise `maxTurns` with it.

**What `permissionMode` is appropriate for automated CI/CD use?**

`bypassPermissions`. In an automated run there is no human to approve a permission
prompt, and `default` would block waiting for input. It is safe here because of what
the allowed tools are: `Read`, `Grep`, `Glob` and read-only MCP queries. No `Write`,
no `Edit`, no `Bash`, and `cwd` is confined to `PROJECT_ROOT`.

(`PermissionMode` is declared as
`'default' | 'acceptEdits' | 'bypassPermissions' | 'plan' | 'delegate' | 'dontAsk'`.)

**How do you convert a Zod schema to JSON Schema, and configure `outputFormat`?**

The starter exports the converted schemas already, using
`zodToJsonSchema(schema, { $refStrategy: 'root' })`. The `$refStrategy: 'root'` option
inlines `$ref` definitions, which the SDK requires. They are used directly:

```ts
outputFormat: { type: 'json_schema', schema: ReviewReportJSONSchema }
```

**How do you iterate the result and extract `structured_output`?**

`query()` returns an async iterable. The loop reads every message, watches
`type: 'assistant'` messages for `tool_use` blocks (which is where the delegation
count comes from), and takes `structured_output` from the terminal `type: 'result'`
message:

```ts
for await (const message of stream) {
  if (message.type === 'result') {
    if (message.subtype !== 'success') throw new ReviewError(/* ... */);
    structured = message.structured_output;
  }
}
```

**`safeParse` or `parse`?**

`safeParse`. A malformed agent response is an expected condition, not an exceptional
one, and `safeParse` returns the issue list so the error names the offending field
paths. `parse` would throw from inside Zod, producing a stack trace where a diagnostic
belongs.

---

## Phase 4 — Production Utilities

### Task 4.1 — Retry with exponential backoff

**How do you implement exponential backoff in JavaScript?**

Double the delay per attempt: `delayMs * Math.pow(2, attempt - 1)`. With the default
`delayMs` of 1000 that gives 1s, 2s, 4s.

**Why is jitter important?**

Without it, every client that failed at the same instant computes the same delay and
returns **together**, recreating the spike that caused the failure. This is the
thundering herd.

The concrete case here: three subagents dispatched in parallel for one file all take a
429 at the same moment. With identical backoff they retry in the same millisecond and
all fail again. A random 0–100 ms offset is small in absolute terms and enough to
desynchronise them.

**How do you wrap `setTimeout` in a promise for async/await?**

```ts
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
await sleep(backoff + jitter);
```

`resolve` is passed directly as the timer callback.

### Task 4.2 — Timeout wrapper

**How does `Promise.race` work?**

It settles with whichever promise settles first and discards the rest. Racing `fn()`
against a timer that rejects yields a timeout.

One consequence the pattern hides: the loser is **not cancelled**. A slow API call
keeps running and keeps consuming quota; it is merely ignored. That is acceptable here
because the goal is to stop the process hanging, not to reclaim the request.

**How do you create a promise that rejects after a delay?**

```ts
new Promise<never>((_, reject) =>
  setTimeout(() => reject(new ReviewError(msg, ErrorCodes.AGENT_TIMEOUT, { timeoutMs })), timeoutMs)
);
```

Typing it `Promise<never>` keeps the race's return type equal to `fn()`'s. The
implementation also clears the timer in a `finally` — otherwise the pending timer keeps
the event loop alive after a fast success and the CLI never exits.

**What error code should a timeout use?**

`ErrorCodes.AGENT_TIMEOUT`, with `{ timeoutMs }` in the metadata so the log says which
limit was hit.

**Where both are integrated.** The orchestrator wraps the SDK call as
`withTimeout(() => withRetry(() => runQuery(...)))`, so the deadline covers the whole
retry sequence rather than each attempt separately. That ordering is deliberate: a
per-attempt timeout with two retries would allow three times the intended wall time.
`maxRetries` defaults to 2 — a review is expensive, and a third attempt would more
often exhaust the deadline than succeed.

### Task 4.3 — Rate limiter

**Why a sliding window instead of fixed time buckets?**

Fixed buckets permit double the limit across a boundary. With a 50-requests-per-minute
cap: 50 requests at 11:00:59 and 50 more at 11:01:00 is 100 requests in two seconds,
and both buckets look compliant. The provider sees the real rate and returns 429.

A sliding window always counts the last 60 seconds from *now*, so the boundary burst
cannot happen. The cost is keeping a history of records instead of a counter, which is
what `pruneOldRecords()` maintains.

**How does the waitQueue pattern work?**

It is a semaphore without polling. When `activeRequests` reaches `maxConcurrent`,
`waitForSlot()` creates a promise and pushes its `resolve` onto `waitQueue`, so the
caller suspends at the `await`. When a request finishes, `release()` shifts one
resolver off the queue and calls it, waking exactly one waiter.

FIFO ordering, no busy-wait, no starvation.

**Why track requests and tokens separately?**

They are independent limits, and either can bind depending on traffic shape. Twenty
requests of 5k tokens is nowhere near 50 requests per minute but consumes 100k tokens
per minute. A hundred requests of 200 tokens exhausts the request limit at 20k tokens.

Code review is the heavy-payload case: sending whole files to three subagents reaches
the token ceiling long before the request ceiling. A single counter would miss the
limit that actually matters here.

---

## Notes on what the implementation measured

| Question | Answer | How it was established |
|---|---|---|
| GitHub MCP tool names | `get_pull_request`, `get_pull_request_files`, `get_file_contents` | logged from a live run's message stream |
| MCP tool naming pattern | `mcp__<server>__<tool>` | same run |
| `maxTurns` / `maxFiles` | 120 / 3 | a five-file PR completed 15 delegations then failed to aggregate; three files aggregate reliably |
| Skills need `settingSources` | yes, `['project']` | probe skill with a marker token, tested both ways |
| `bypassPermissions` valid | yes | SDK type declaration |
| Concurrency of runs | one review at a time | two simultaneous runs both timed out; the same PR completed in 122s when run alone |
| `octocat/Hello-World#1` is not analysable | 0 files, 0 delegations | ran it; the pull request changes a single file named `README`, with no extension and no code |
| Lint findings change the review | 11 issues → 25 | the same pull request, re-reviewed after Stage 1 gained the ESLint step |

### What the ESLint server actually contributes

The second MCP server was configured from the start but never reached: no
`mcp__eslint__*` tool appeared in any logged run, so "integrates external tools"
was true of one server and unproven of the other. Stage 1 of the orchestrator
prompt now lints the JavaScript and TypeScript files it fetched, and passes the
findings to the code-quality subagent as supporting evidence.

Re-reviewing the same pull request with that step in place took the review from
11 code-quality issues to 25. The lint output is visible in the result rather
than merely in the log: two findings cite it directly — an unused parameter at
specific columns, and the observation that the flagged names are parameters in a
type position rather than dead code, which is the kind of judgement a linter
cannot make on its own but can prompt.

That is the division of labour the step is for. The linter settles mechanically
what it settles reliably, and the subagents spend their reasoning on what it
cannot see: accessibility, mutation of shared arrays, a placeholder that
promises behaviour the component does not implement.

Unavailability is explicitly non-blocking. The prompt tells the orchestrator to
note the absence and carry on, because lint is corroboration and not a gate —
a reviewer without the ESLint server should still get a review.

### The integration checkpoint against `octocat/Hello-World#1`

The brief names this pull request as the integration checkpoint. It was run, and
it completed successfully in 38s: the orchestrator fetched the pull request,
fetched its file list, found nothing analysable and returned an empty report
without delegating.

That is the correct behaviour, but it is a weak checkpoint. The pull request
changes one file — `README`, no extension, six lines added — so there is nothing
for three subagents specialising in code quality, test coverage and refactoring
to read. A run that delegates zero times cannot demonstrate subagent integration
or external tool use, which is what a checkpoint is for.

So the checkpoint is reported twice: `reports/octocat_Hello-World_1.*` is the
named run, kept as evidence that it executed; the delegation and tool-use
evidence lives in the `simple-todo-app` runs, which analyse real code and produce
nine delegations each.

Running it also exposed a real defect. Every run wrote both the per-PR file and
the generic `report.{ext}`, so this empty review replaced the dense one — a
silent downgrade of the deliverable an evaluator is most likely to open. The
generic copy is now written only when the report has at least one file review.
The per-PR file is still always written: it is addressed by name and overwrites
only itself.
