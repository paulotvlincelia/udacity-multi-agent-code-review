# Udacity — Agentic Engineering with Claude SDK

Course project: **Enterprise Multi-Agent Code Review Orchestrator** — a multi-agent
system that analyses GitHub pull requests for code quality, test coverage and
refactoring opportunities, then synthesises the findings into a validated report in
JSON, Markdown and HTML.

Three specialised subagents run in parallel per file, each with its own prompt, tool
set and severity criteria, coordinated by an orchestrator that spawns them through the
SDK's `Task` tool and validates the aggregate against a Zod schema.

## Layout

```
.
├── CLAUDE.md               # working rules (AGENTS.md symlinks here)
├── DESIGN.md               # answers to the course's design questions
├── DEVIATIONS.md           # documented departures from the brief, with evidence
├── docs/
│   ├── INDEX.md            # start here
│   └── reference/          # deliverables, rubric, contracts, risks, submission
├── scripts/
│   └── verify-submission.sh   # 16-check pre-submission gate
├── .specs/features/code-review-orchestrator/
│   ├── plan.md             # 13 slices, 73 acceptance criteria
│   ├── checks.md           # 74 checks, each with the command that settles it
│   └── verification.md     # independent verification report
└── project/starter/        # the implementation
    ├── src/
    │   ├── agents/         # three AgentDefinitions
    │   ├── prompts/        # orchestrator + three agent prompts
    │   ├── config/         # GitHub and ESLint MCP servers
    │   ├── orchestrator.ts # query(), Task, agents, outputFormat
    │   └── main.ts         # CLI with argument and env validation
    ├── tests/              # 101 tests
    ├── .claude/skills/     # security-analysis, typescript-patterns, +provided
    └── reports/            # the nine submitted deliverables
```

## Quick start

```bash
cd project/starter
npm install
cp .env.example .env
```

Then set two values in `.env`:

```bash
ANTHROPIC_MODEL=claude-sonnet-4-5-20250929
PROJECT_ROOT=/absolute/path/to/project/starter   # must contain .claude/skills/
```

Authentication takes any one of three paths — an `ANTHROPIC_API_KEY`, AWS Bedrock
credentials, or an authenticated Claude CLI session that the SDK inherits. The CLI
reports which one it used at startup.

```bash
npm run dev -- <owner> <repo> <pr-number>

# example
npm run dev -- octocat Hello-World 1
```

Reports land in `reports/` in all three formats.

## Verify

```bash
npm run lint     # tsc --noEmit, strict
npm test         # 101 tests
npm run build    # emits dist/
npm start        # same CLI, compiled

../../scripts/verify-submission.sh   # the full pre-submission gate
```

## Notes worth knowing before running it

**One review at a time.** Concurrent runs against the same CLI session contend and
both time out; the same pull request completes normally when run alone.

**`maxFiles` defaults to 3.** Each file fans out to three subagents and adds an entry
to the final report. At five files the analyses all succeeded and the aggregation step
emitted nothing, losing the report after the expensive work had finished. Raise it
with `MAX_FILES=5` and raise `maxTurns` to match.

**Skills need `settingSources: ['project']`.** Without it the SDK runs in isolation
mode and never reads `.claude/skills/` — the `Skill` tool still appears in the trace,
so the failure is silent. See [DESIGN.md](DESIGN.md).

See [docs/INDEX.md](docs/INDEX.md) for the full reference set, and
[DEVIATIONS.md](DEVIATIONS.md) for where this submission departs from the brief and
why.
